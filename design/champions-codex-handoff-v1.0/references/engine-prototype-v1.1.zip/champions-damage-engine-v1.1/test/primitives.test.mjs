import test from 'node:test';
import assert from 'node:assert/strict';
import { statAt50, inferPoints, applyStatStage, bareBaseDamageAt50, bareRandomRolls, koChanceAfterHits, percentageOneDecimal } from '../dist/src/primitives.js';

test('Champions stat point formulas (HP, non-HP, 0.9, 1.0, 1.1)', () => {
  assert.equal(statAt50('hp', 100, 32), 207);
  assert.equal(statAt50('attack', 100, 32, 1.1), 167);
  assert.equal(statAt50('attack', 100, 32, 1), 152);
  assert.equal(statAt50('attack', 100, 32, 0.9), 136);
});
test('reverse stat points matches and returns null for impossible stats', () => {
  assert.equal(inferPoints({kind:'attack',base:100,targetStat:167,nature:1.1,hiddenOtherPoints:34,previousPoints:0}), 32);
  assert.equal(inferPoints({kind:'hp',base:100,targetStat:208,hiddenOtherPoints:0,previousPoints:32}), null);
  assert.equal(inferPoints({kind:'attack',base:100,targetStat:167,nature:1.1,hiddenOtherPoints:35,previousPoints:32}), null);
});
test('stat stages use rational multiples and truncate', () => {
  assert.equal(applyStatStage(101, -1), 67);
  assert.equal(applyStatStage(101, 1), 151);
  assert.equal(applyStatStage(101, 6), 404);
});
test('wiki reference: Lv50 100 BP 182 Attack 189 Defense = base 44', () => {
  assert.equal(bareBaseDamageAt50(100,182,189),44);
  assert.deepEqual(bareRandomRolls(44), [37,37,38,38,39,39,40,40,40,41,41,42,42,43,43,44]);
});
test('independent-roll KO probability: 9/16 chance to KO in 1 hit', () => {
  const rolls=[...Array(7).fill(90),...Array(9).fill(100)];
  const c=koChanceAfterHits(rolls,95,1);
  assert.equal(c.numerator,9n);
  assert.equal(c.denominator,16n);
  assert.equal(percentageOneDecimal(c),'56.3%');
  const c2=koChanceAfterHits(rolls,175,2);
  assert.equal(c2.numerator,256n);
  assert.equal(c2.denominator,256n);
});
test('zero damage is not fabricated as 1 damage', () => {
  const rolls=Array(16).fill(0);
  assert.equal(koChanceAfterHits(rolls,5,2).numerator,0n);
});
test('invalid inputs reject rather than silently clamp', () => {
  assert.throws(() => statAt50('attack',100,33,1),RangeError);
  assert.throws(() => applyStatStage(100,7),RangeError);
  assert.throws(() => bareBaseDamageAt50(100,100,0),RangeError);
});
