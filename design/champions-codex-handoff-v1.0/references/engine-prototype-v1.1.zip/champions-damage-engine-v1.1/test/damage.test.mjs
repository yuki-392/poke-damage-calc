import test from 'node:test';
import assert from 'node:assert/strict';
import {calculateDamage,RULE_VERSION} from '../dist/src/damage.js';
import {typeEffectiveness,TYPES} from '../dist/src/type-chart.js';
import {analyzeKo,earliestKoChance,formatKo} from '../dist/src/ko.js';
import {calculateTop50} from '../dist/src/top50.js';

const statsA={hp:100,attack:130,defense:100,spAttack:130,spDefense:100,speed:100};
const statsD={hp:100,attack:100,defense:137,spAttack:100,spDefense:137,speed:100};
const kinds=['attack','defense','spAttack','spDefense','speed'];
const nature=Object.fromEntries(kinds.map(s=>[s,1]));
const pointsA={hp:0,attack:32,defense:0,spAttack:32,spDefense:0,speed:0};
const pointsD={hp:32,attack:0,defense:32,spAttack:0,spDefense:0,speed:0};
const form=(id,types,baseStats)=>({id,types,baseStats,allowedAbilities:['neutral','adaptability','technician','huge-power','guts','filter','multiscale','unsupported-ability']});
const move=(moveId,moveType='rock',power=100,category='physical',scope='single',effect='standard')=>({moveId,moveType,power,category,scope,effect});
const db={version:'fixtures-1',forms:{attacker:form('attacker',['dragon','ground'],statsA),defender:form('defender',['psychic'],statsD),flying:form('flying',['flying'],statsD),rock:form('rock',['rock'],statsD),ice:form('ice',['ice'],statsD)},
 moves:{edge:move('edge'),flame:move('flame','fire'),water:move('water','water'),quake:move('quake','ground',100,'physical','allAdjacent'),electric:move('electric','electric',100,'special'),dragon:move('dragon','dragon'),punch:move('punch','fighting',60),shadow:move('shadow','ghost',100),status:move('status','normal',null,'status'),variable:move('variable','normal',null,'physical','single','variable-power'),grass:move('grass','grass')},
 abilities:{neutral:'neutral',adaptability:'adaptability',technician:'technician','huge-power':'huge-power',guts:'guts',filter:'filter',multiscale:'multiscale','unsupported-ability':'unsupported'},
 items:{leftovers:'neutral','life-orb':'life-orb',mystery:'unsupported'}};
const initial=(id,statPoints,currentHp)=>({pokemonFormId:id,statPoints:{...statPoints},nature:{...nature},abilityId:null,itemId:null,isMega:false,currentHp,stages:{},status:'none'});
function setup(moveId='edge'){
 return {attacker:initial('attacker',pointsA,175),defender:initial('defender',pointsD,207),
 move:{moveId,moveType:db.moves[moveId].moveType,category:db.moves[moveId].category,scope:db.moves[moveId].scope},
 conditions:{format:'singles',weather:'none',terrain:'none',targetsActuallyHit:1,critical:false,attackerHelpingHand:false,
 reflectOnDefenderSide:false,lightScreenOnDefenderSide:false,auroraVeilOnDefenderSide:false,
 attackerGrounded:null,defenderGrounded:null,moveSpecificConditions:{}},masterDataVersion:db.version,ruleVersion:RULE_VERSION};
}
const calc=(req)=>calculateDamage(req,db);
const rolls=r=>r.outcomes.flatMap(x=>Array(x.weight).fill(x.damage));

test('type chart: 18 attacks and dual modifiers, immunities',()=>{
 assert.equal(TYPES.length,18);
 assert.equal(typeEffectiveness('rock',['fire','flying']),4);
 assert.equal(typeEffectiveness('ice',['water','flying']),1);
 assert.equal(typeEffectiveness('electric',['ground']),0);
 assert.equal(typeEffectiveness('normal',['ghost']),0);
 assert.equal(typeEffectiveness('dragon',['fairy']),0);
 assert.equal(typeEffectiveness('fighting',['normal']),2);
 assert.equal(typeEffectiveness('steel',['fairy']),2);
 assert.equal(typeEffectiveness('grass',['fire','steel']),0.25);
 assert.throws(()=>typeEffectiveness('fire',['fire','fire']),RangeError);
});
test('wiki bare reference through complete pipeline (no modifiers): 37–44',()=>{
 const r=calc(setup());assert.equal(r.status,'ok');assert.equal(r.minDamage,37);assert.equal(r.maxDamage,44);
 assert.deepEqual(rolls(r),[37,37,38,38,39,39,40,40,40,41,41,42,42,43,43,44]);
 assert.equal(r.outcomes.reduce((s,e)=>s+e.weight,0),16);
});
test('type/STAB and type immunity do not fake damage',()=>{
 const req=setup('quake'); const r=calc(req);
 assert.equal(r.status,'ok');assert.ok(r.appliedEffects.includes('STAB'));
 req.defender.pokemonFormId='flying';req.defender.currentHp=207;
 const z=calc(req);assert.equal(z.status,'ok');assert.equal(z.minDamage,0);assert.equal(z.maxDamage,0);assert.equal(z.knockout.kind,'impossible');
});
test('sun boost and rain weakening occur before the random roll',()=>{
 const q=setup('flame');q.conditions.weather='sun';const x=calc(q);
 assert.equal(x.status,'ok');assert.deepEqual([x.minDamage,x.maxDamage],[56,66]);
 q.conditions.weather='rain';const y=calc(q);assert.deepEqual([y.minDamage,y.maxDamage],[18,22]);
});
test('spread only in doubles AND two actual targets, not just doubles',()=>{
 const q=setup('quake');q.move.moveType='ground';q.conditions.format='doubles';
 const solo=calc(q);assert.equal(solo.status,'ok');
 q.conditions.targetsActuallyHit=2; const spread=calc(q);
 assert.equal(spread.status,'ok');assert.ok(spread.minDamage<solo.minDamage);
 assert.ok(spread.appliedEffects.includes('spread-0.75'));
 q.conditions.format='singles';assert.equal(calc(q).status,'invalid');
});
test('crit ignores attacker negative and defender positive stages and walls',()=>{
 const q=setup();q.attacker.stages.attack=-4;q.defender.stages.defense=4;
 q.conditions.reflectOnDefenderSide=true;
 const without=calc(q);assert.equal(without.status,'ok');
 q.conditions.critical=true;const withCrit=calc(q);assert.equal(withCrit.status,'ok');
 assert.ok(withCrit.maxDamage>without.maxDamage);
 assert.ok(!withCrit.appliedEffects.includes('screen'));
});
test('screens: singles half vs doubles roughly 2/3; physical/special split',()=>{
 const q=setup();const plain=calc(q);q.conditions.reflectOnDefenderSide=true;
 const single=calc(q); assert.equal(single.status,'ok');
 q.conditions.format='doubles';const double=calc(q);assert.equal(double.status,'ok');
 assert.ok(single.maxDamage<double.maxDamage && double.maxDamage<plain.maxDamage);
 q.conditions.reflectOnDefenderSide=false;q.conditions.lightScreenOnDefenderSide=true;
 assert.equal(calc(q).maxDamage,plain.maxDamage);
});
test('burn physical reduces damage, not special',()=>{
 const q=setup();const full=calc(q).maxDamage;
 q.attacker.status='burn';assert.ok(calc(q).maxDamage<full);
 q.move=setup('electric').move;assert.equal(calc(q).status,'ok');
});
test('sand and snow defense boosts affect only the correct type/category',()=>{
 const q=setup('electric');q.defender.pokemonFormId='rock';
 const base=calc(q);q.conditions.weather='sand';const boosted=calc(q);
 assert.ok(boosted.maxDamage<base.maxDamage);
 const y=setup();y.defender.pokemonFormId='ice';
 const noSnow=calc(y);y.conditions.weather='snow';const snow=calc(y);
 assert.ok(snow.maxDamage<noSnow.maxDamage);
});
test('grounded state needed for terrain; boost or resist when known',()=>{
 const q=setup('electric');q.conditions.terrain='electric';
 assert.equal(calc(q).status,'unsupported');
 q.conditions.attackerGrounded=true;q.conditions.defenderGrounded=true;
 const grounded=calc(q);assert.equal(grounded.status,'ok');
 q.conditions.attackerGrounded=false;const airborne=calc(q);assert.ok(grounded.maxDamage>airborne.maxDamage);
 const dragon=setup('dragon');dragon.conditions.terrain='misty';dragon.conditions.attackerGrounded=true;dragon.conditions.defenderGrounded=true;
 const misty=calc(dragon),ordinary=calc(setup('dragon'));
 assert.ok(misty.maxDamage<ordinary.maxDamage);
});
test('supported ability and item effects with explicit registry',()=>{
 const q=setup('punch');q.attacker.abilityId='technician';const tech=calc(q);
 q.attacker.abilityId=null;assert.ok(tech.maxDamage>calc(q).maxDamage);
 q.attacker.itemId='life-orb';assert.ok(calc(q).maxDamage>calc({...q,attacker:{...q.attacker,itemId:null}}).maxDamage);
 q.attacker.abilityId='unsupported-ability';const nope=calc(q);assert.equal(nope.status,'unsupported');
 q.attacker.abilityId=null;q.attacker.itemId='mystery';assert.equal(calc(q).status,'unsupported');
});
test('invalid stat points, HP, version and unsupported move cannot return ok',()=>{
 let q=setup();q.defender.statPoints.hp=33;assert.equal(calc(q).status,'invalid');
 q=setup();q.defender.currentHp=208;assert.equal(calc(q).status,'invalid');
 q=setup();q.masterDataVersion='wrong';assert.equal(calc(q).status,'unsupported');
 q=setup('variable');assert.equal(calc(q).status,'unsupported');
 q=setup('status');assert.equal(calc(q).status,'nonDamaging');
});
test('earliest KO probability is exact (independent uniform rolls) and formatting includes >=3 hits',()=>{
 const c=earliestKoChance([1,2],3,2);
 assert.deepEqual(c,{numerator:3n,denominator:4n});
 assert.equal(formatKo(analyzeKo([1,2],3)),'乱数2発(75.0%)');
 // Five hits of 10–11 damage against HP50 are guaranteed.
 assert.equal(formatKo(analyzeKo([10,11],50)),'確定5発');
 assert.match(formatKo(analyzeKo([7,9],30)),/乱数4発\(/);
});
test('TOP50 adapter performs 4x50 and normal mode agrees for same conditions',()=>{
 const q=setup();const defenders=Array.from({length:50},(_,i)=>({pokemonFormId:'defender',rank:i+1,buildKind:'estimated',build:initial('defender',pointsD,207)}));
 const results=calculateTop50({common:{attacker:q.attacker,conditions:q.conditions,masterDataVersion:q.masterDataVersion,ruleVersion:q.ruleVersion},
 moves:[q.move,q.move,q.move,q.move],defenders,rankingSnapshotId:'fixture'},db);
 assert.equal(results.length,50);assert.equal(results.reduce((s,x)=>s+x.moveResults.length,0),200);
 assert.deepEqual(results[0].moveResults[0],calc(q));
 assert.equal(results[49].rank,50);
});
test('incorrect ability for form, mega identity, and terrain move metadata fail closed',()=>{
 let q=setup(); q.attacker.abilityId='nonexistent-ability';
 assert.equal(calc(q).status,'invalid');
 q=setup(); q.attacker.isMega=true;
 assert.equal(calc(q).status,'invalid');
 q=setup(); q.conditions.moveSpecificConditions={unknownMultiplier:true};
 assert.equal(calc(q).status,'unsupported');
});
test('KO distribution respects repeated outcomes, percentages relative to max HP',()=>{
 const q=setup();q.defender.currentHp=40;
 const result=calc(q);
 assert.equal(result.status,'ok');
 assert.equal(result.minPercentOfMaxHp,37/207*100);
 assert.equal(result.knockout.kind,'random');
 assert.equal(result.knockout.earliestHits,1);
 assert.match(formatKo(result.knockout),/^乱数1発\(\d+\.\d%\)$/);
});
