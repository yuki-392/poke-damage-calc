# Champions damage engine — Phase 1 v1.1

Partial TypeScript execution engine for the Pokémon Champions damage calculator.

**This is NOT a production-complete calculator.** It supports documented baseline effects and responds `unsupported` for other effects instead of returning false precision.

## Quick start

Requirements: Node.js 22+ and TypeScript compiler (`tsc`, available in the authoring environment).

```sh
npm test
npm run build
node examples/quickstart.mjs
```

The example prints `37〜44` damage using the user-provided Wiki's base calculation example (Lv50, 100 power, 182 attack, 189 defense), with a neutral hit.

Core entry points: `calculateDamage(request, catalog)` in `src/damage.ts`, and `calculateTop50(...)` in `src/top50.ts`. There is deliberately **no network call**, hardcoded rankings, database connection, or browser UI in this package.

Read `docs/implementation-v1.1.md` for exact supported rules, limitations, and validation plan.

## Existing project compatibility

- Starts from the `v1.0` primitives and input/output contracts.
- `status` is `ok | nonDamaging | unsupported | invalid`.
- Uses `masterDataVersion` and `ruleVersion` to avoid silently mixing outdated rule inputs.
- `MasterCatalog` must be built from versioned game data and vetted effect categories before production use.

Source reference: https://champions.pokewiki.net/ダメージ計算式
