// Run after `npm run build`: node examples/quickstart.mjs
import {calculateDamage, RULE_VERSION} from '../dist/src/damage.js';
import {formatKo} from '../dist/src/ko.js';
const neutralNature={attack:1,defense:1,spAttack:1,spDefense:1,speed:1};
const zeroPoints={hp:0,attack:0,defense:0,spAttack:0,spDefense:0,speed:0};
const catalog={version:'example-1',
 forms:{
  exampleAttacker:{id:'exampleAttacker',types:['ground','dragon'],allowedAbilities:[],
    baseStats:{hp:100,attack:130,defense:100,spAttack:100,spDefense:100,speed:100}},
  exampleDefender:{id:'exampleDefender',types:['psychic'],allowedAbilities:[],
    baseStats:{hp:100,attack:100,defense:137,spAttack:100,spDefense:137,speed:100}}
 },
 moves:{rockMove:{moveId:'rockMove',moveType:'rock',category:'physical',scope:'single',power:100,effect:'standard'}},
 abilities:{},items:{}};
const build=(pokemonFormId,pts,currentHp)=>({pokemonFormId,nature:{...neutralNature},statPoints:{...zeroPoints,...pts},
  abilityId:null,itemId:null,isMega:false,currentHp,stages:{},status:'none'});
const request={
 attacker:build('exampleAttacker',{attack:32},175),
 defender:build('exampleDefender',{defense:32,hp:32},207),
 move:{moveId:'rockMove',moveType:'rock',category:'physical',scope:'single'},
 conditions:{format:'singles',weather:'none',terrain:'none',targetsActuallyHit:1,critical:false,
  attackerHelpingHand:false,reflectOnDefenderSide:false,lightScreenOnDefenderSide:false,auroraVeilOnDefenderSide:false,
  attackerGrounded:null,defenderGrounded:null,moveSpecificConditions:{}},
 masterDataVersion:'example-1',ruleVersion:RULE_VERSION,
};
const result=calculateDamage(request,catalog);
if(result.status!=='ok') throw new Error(JSON.stringify(result));
console.log(`ダメージ: ${result.minDamage}〜${result.maxDamage}`);
console.log(`割合: ${result.minPercentOfMaxHp.toFixed(1)}〜${result.maxPercentOfMaxHp.toFixed(1)}%`);
console.log(`撃破: ${formatKo(result.knockout)}`);
