import type {DamageRequest,DamageResult,PerPokemonTop50Result,Build,AttackMove} from './contracts';
import {calculateDamage,type MasterCatalog} from './damage';
export interface Top50Defender {
 pokemonFormId:string; rank:number; buildKind:'measured'|'estimated'|'custom'; build:Build;
}
/** Shared rules, no mutation: caller owns UI-local condition and build state. */
export function calculateTop50(input:{common:Omit<DamageRequest,'defender'|'move'>;
  moves:readonly AttackMove[]; defenders:readonly Top50Defender[]; rankingSnapshotId:string},catalog:MasterCatalog):PerPokemonTop50Result[] {
 if(input.moves.length<1||input.moves.length>4) throw new RangeError('TOP50 requires 1–4 moves');
 if(input.defenders.length!==50) throw new RangeError('TOP50 requires exactly 50 defenders');
 const ranks=input.defenders.map(x=>x.rank);
 if(new Set(ranks).size!==50||ranks.some(r=>!Number.isInteger(r)||r<1||r>50))throw new RangeError('invalid ranks');
 return input.defenders.map(entry=>({
   rankingSnapshotId:input.rankingSnapshotId,pokemonFormId:entry.pokemonFormId,
   rank:entry.rank,buildKind:entry.buildKind,
   moveResults:input.moves.map(move=>calculateDamage({...input.common,defender:entry.build,move},catalog)) as DamageResult[],
 }));
}
