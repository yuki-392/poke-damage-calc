/** Pokémon Champions damage-engine verification primitives.
 * THIS IS NOT A COMPLETE DAMAGE CALCULATOR.
 * It deliberately omits STAB, type matchups, weather, terrain, spread moves,
 * abilities, items, critical hits and other post-base modifiers.
 */
export type StatKind = 'hp' | 'attack' | 'defense' | 'spAttack' | 'spDefense' | 'speed';
export type NatureFactor = 0.9 | 1.0 | 1.1;

const assertIntRange = (name: string, n: number, min: number, max: number): void => {
  if (!Number.isInteger(n) || n < min || n > max) {
    throw new RangeError(`${name} must be an integer in [${min}, ${max}]`);
  }
};
const validateNature = (nature: number): void => {
  if (nature !== 0.9 && nature !== 1 && nature !== 1.1) {
    throw new RangeError('nature must be 0.9, 1.0, or 1.1');
  }
};

export function statAt50(kind: StatKind, base: number, points: number, nature: NatureFactor = 1): number {
  assertIntRange('base stat', base, 1, 255);
  assertIntRange('stat points', points, 0, 32);
  validateNature(nature);
  return kind === 'hp' ? base + points + 75 : Math.floor((base + points + 20) * nature + 1e-10);
}

/** Returns null when an entered exact stat cannot be represented legally.
 * When multiple points lead to the same exact stat, prefer the closest to previousPoints,
 * then the smaller point value. hiddenOtherPoints counts ALL other stat points,
 * including stats not visible in the UI.
 */
export function inferPoints(input: {
  kind: StatKind; base: number; targetStat: number;
  nature?: NatureFactor; hiddenOtherPoints: number; previousPoints: number;
}): number | null {
  const { kind, base, targetStat, hiddenOtherPoints, previousPoints } = input;
  assertIntRange('hidden other stat points', hiddenOtherPoints, 0, 66);
  assertIntRange('previous stat points', previousPoints, 0, 32);
  if (!Number.isInteger(targetStat) || targetStat < 1) return null;
  const candidates: number[] = [];
  for (let points = 0; points <= Math.min(32, 66 - hiddenOtherPoints); points++) {
    if (statAt50(kind, base, points, input.nature ?? 1) === targetStat) candidates.push(points);
  }
  candidates.sort((a, b) => (Math.abs(a - previousPoints) - Math.abs(b - previousPoints)) || (a - b));
  return candidates[0] ?? null;
}

export function applyStatStage(value: number, stage: number): number {
  assertIntRange('stat value', value, 1, 9999);
  assertIntRange('stage', stage, -6, 6);
  return stage >= 0
    ? Math.floor((value * (2 + stage)) / 2)
    : Math.floor((value * 2) / (2 - stage));
}

/** The unmodified base-damage formula only: excludes ALL battle modifiers. */
export function bareBaseDamageAt50(power: number, attack: number, defense: number): number {
  assertIntRange('power', power, 1, 999);
  assertIntRange('attack', attack, 1, 9999);
  assertIntRange('defense', defense, 1, 9999);
  const term = Math.floor((22 * power * attack) / defense);
  return Math.floor(term / 50) + 2;
}

/** 16 equally likely damage rolls, BEFORE STAB, type, ability, item etc.
 * Not a final battle damage distribution and MUST NOT be displayed as one.
 */
export function bareRandomRolls(unmodifiedBaseDamage: number): number[] {
  assertIntRange('unmodifiedBaseDamage', unmodifiedBaseDamage, 1, 999999);
  return Array.from({ length: 16 }, (_, i) => Math.floor((unmodifiedBaseDamage * (85 + i)) / 100));
}

export interface ExactChance { numerator: bigint; denominator: bigint }
/** For a FIXED set of battle conditions, independent identical damage rolls,
 * no accuracy, recoil, recovery, end-of-turn effects, multihits or changes of state.
 * Engineering reference implementation; optimize for large hit counts in production.
 */
export function koChanceAfterHits(rolls: readonly number[], currentHp: number, hits: number): ExactChance {
  if (rolls.length === 0 || rolls.some(v => !Number.isInteger(v) || v < 0)) throw new RangeError('invalid damage rolls');
  assertIntRange('currentHp', currentHp, 1, 99999);
  assertIntRange('hits', hits, 1, 1000);
  let pmf = new Map<number, bigint>([[0, 1n]]);
  for (let i = 0; i < hits; i++) {
    const next = new Map<number, bigint>();
    for (const [sum, count] of pmf) {
      for (const damage of rolls) {
        const capped = Math.min(currentHp, sum + damage);
        next.set(capped, (next.get(capped) ?? 0n) + count);
      }
    }
    pmf = next;
  }
  return { numerator: pmf.get(currentHp) ?? 0n, denominator: BigInt(rolls.length) ** BigInt(hits) };
}

/** UI rendering only. Percentage is a presentation value, not the probability model. */
export function percentageOneDecimal(chance: ExactChance): string {
  if (chance.denominator <= 0n) throw new RangeError('denominator must be positive');
  const percentTenthsRounded = (chance.numerator * 1000n * 2n + chance.denominator) / (chance.denominator * 2n);
  return `${percentTenthsRounded / 10n}.${percentTenthsRounded % 10n}%`;
}
