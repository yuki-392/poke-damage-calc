/** Target production contracts. No full battle engine is implemented in this package. */
export type BattleFormat = 'singles' | 'doubles';
export type StatId = 'hp' | 'attack' | 'defense' | 'spAttack' | 'spDefense' | 'speed';
export type BattleWeather = 'none' | 'sun' | 'rain' | 'sand' | 'snow';
export type BattleTerrain = 'none' | 'electric' | 'grassy' | 'misty' | 'psychic';
export type DamageCategory = 'physical' | 'special' | 'status';
export type StatPoints = Record<StatId, number>;
export type NatureFactors = Omit<Record<StatId, 0.9 | 1 | 1.1>, 'hp'>;

export interface Build {
  pokemonFormId: string;
  statPoints: StatPoints; // all SIX values retained even if UI shows only a subset
  nature: NatureFactors; // the UI edits one relevant multiplier, raw full nature retained
  abilityId: string | null;
  itemId: string | null;
  isMega: boolean;
  currentHp: number;
  stages: Partial<Record<Exclude<StatId, 'hp'>, number>>;
  status: 'none' | 'burn' | 'poison' | 'badPoison' | 'paralysis' | 'sleep' | 'freeze';
}

export interface AttackMove {
  moveId: string;
  category: DamageCategory;
  moveType: string;
  scope: 'single' | 'adjacentFoes' | 'allAdjacent' | 'other';
}
export interface CombatConditions {
  format: BattleFormat;
  weather: BattleWeather;
  terrain: BattleTerrain;
  targetsActuallyHit: 1 | 2 | 3; // spread reduction only when 2+
  critical: boolean;
  attackerHelpingHand: boolean;
  reflectOnDefenderSide: boolean;
  lightScreenOnDefenderSide: boolean;
  auroraVeilOnDefenderSide: boolean;
  attackerGrounded: boolean | null;
  defenderGrounded: boolean | null;
  moveSpecificConditions: Record<string, boolean | number | string>;
}
export interface DamageRequest {
  attacker: Build;
  defender: Build;
  move: AttackMove;
  conditions: CombatConditions;
  masterDataVersion: string;
  ruleVersion: string;
}
/** Damage outcomes form a weighted PMF; 16 uniform rolls are a special case. */
export interface WeightedDamageOutcome { damage: number; weight: number }
export type KoAnalysis =
  | { kind: 'guaranteed'; hits: number }
  | { kind: 'random'; earliestHits: number; guaranteedHits: number;
      chanceAtEarliest: { numerator: string; denominator: string } }
  | { kind: 'impossible' };

export type DamageResult =
  | { status: 'ok'; outcomes: readonly WeightedDamageOutcome[];
      minDamage: number; maxDamage: number;
      minPercentOfMaxHp: number; maxPercentOfMaxHp: number;
      currentHpUsed: number; knockout: KoAnalysis;
      appliedEffects: readonly string[]; warnings: readonly string[] }
  | { status: 'nonDamaging'; explanation: string }
  | { status: 'unsupported'; codes: readonly string[]; explanation: string }
  | { status: 'invalid'; fields: readonly string[]; explanation: string };

export interface PerPokemonTop50Result {
  rankingSnapshotId: string;
  pokemonFormId: string;
  rank: number;
  buildKind: 'measured' | 'estimated' | 'custom';
  moveResults: readonly DamageResult[]; // 1–4 moves
}
