/** Gen 6+ eighteen-type offensive chart. Neutral matchups are omitted. */
export const TYPES = [
 'normal','fire','water','electric','grass','ice','fighting','poison','ground',
 'flying','psychic','bug','rock','ghost','dragon','dark','steel','fairy',
] as const;
export type PokemonType = typeof TYPES[number];

const chart: Record<PokemonType, { super: readonly PokemonType[]; resist: readonly PokemonType[]; immune: readonly PokemonType[] }> = {
 normal:   {super:[], resist:['rock','steel'], immune:['ghost']},
 fire:     {super:['grass','ice','bug','steel'], resist:['fire','water','rock','dragon'], immune:[]},
 water:    {super:['fire','ground','rock'], resist:['water','grass','dragon'], immune:[]},
 electric: {super:['water','flying'], resist:['electric','grass','dragon'], immune:['ground']},
 grass:    {super:['water','ground','rock'], resist:['fire','grass','poison','flying','bug','dragon','steel'], immune:[]},
 ice:      {super:['grass','ground','flying','dragon'], resist:['fire','water','ice','steel'], immune:[]},
 fighting: {super:['normal','ice','rock','dark','steel'], resist:['poison','flying','psychic','bug','fairy'], immune:['ghost']},
 poison:   {super:['grass','fairy'], resist:['poison','ground','rock','ghost'], immune:['steel']},
 ground:   {super:['fire','electric','poison','rock','steel'], resist:['grass','bug'], immune:['flying']},
 flying:   {super:['grass','fighting','bug'], resist:['electric','rock','steel'], immune:[]},
 psychic:  {super:['fighting','poison'], resist:['psychic','steel'], immune:['dark']},
 bug:      {super:['grass','psychic','dark'], resist:['fire','fighting','poison','flying','ghost','steel','fairy'], immune:[]},
 rock:     {super:['fire','ice','flying','bug'], resist:['fighting','ground','steel'], immune:[]},
 ghost:    {super:['psychic','ghost'], resist:['dark'], immune:['normal']},
 dragon:   {super:['dragon'], resist:['steel'], immune:['fairy']},
 dark:     {super:['psychic','ghost'], resist:['fighting','dark','fairy'], immune:[]},
 steel:    {super:['ice','rock','fairy'], resist:['fire','water','electric','steel'], immune:[]},
 fairy:    {super:['fighting','dragon','dark'], resist:['fire','poison','steel'], immune:[]},
};

export function isPokemonType(s: unknown): s is PokemonType {
 return typeof s === 'string' && (TYPES as readonly string[]).includes(s);
}
export function typeEffectiveness(attack: PokemonType, defenders: readonly PokemonType[]): number {
 if (defenders.length < 1 || defenders.length > 2 || new Set(defenders).size !== defenders.length) {
   throw new RangeError('defending types must contain one or two unique types');
 }
 let factor = 1;
 for(const target of defenders) {
   if (chart[attack].immune.includes(target)) return 0;
   if (chart[attack].super.includes(target)) factor *= 2;
   else if (chart[attack].resist.includes(target)) factor /= 2;
 }
 return factor;
}
