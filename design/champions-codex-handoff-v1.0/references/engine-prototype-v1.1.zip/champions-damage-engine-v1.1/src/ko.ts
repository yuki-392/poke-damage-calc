import type { ExactChance } from './primitives';
import { percentageOneDecimal } from './primitives';
import type { KoAnalysis } from './contracts';
/** Count the probability that the earliest possible number of hits KO.
 * Work with the small amount of damage missing from maximal hits, rather than
 * tracking every total damage sum for each of up to hundreds of hits.
 * All individual rolls (including duplicates) are equiprobable. */
export function earliestKoChance(rolls: readonly number[], hp: number, hits: number): ExactChance {
 if (!Number.isInteger(hp) || hp < 1 || !Number.isInteger(hits) || hits < 1 ||
     !rolls.length || rolls.some(n => !Number.isInteger(n) || n < 0)) throw new RangeError('invalid KO input');
 const max = Math.max(...rolls);
 if (max === 0) return {numerator:0n,denominator:BigInt(rolls.length)**BigInt(hits)};
 const allowance = hits * max - hp;
 if (allowance < 0) return {numerator:0n,denominator:BigInt(rolls.length)**BigInt(hits)};
 const deficits = rolls.map(d => max-d);
 let dp = new Map<number,bigint>([[0,1n]]);
 for(let i=0;i<hits;i++) {
   const next = new Map<number,bigint>();
   for(const [sum,n] of dp) for(const d of deficits) {
     const s=sum+d;
     if(s<=allowance) next.set(s,(next.get(s)||0n)+n);
   }
   dp=next;
 }
 let num=0n;
 for(const n of dp.values()) num+=n;
 return {numerator:num,denominator:BigInt(rolls.length)**BigInt(hits)};
}
export function analyzeKo(rolls:readonly number[], currentHp:number):KoAnalysis {
 if (!Number.isInteger(currentHp) || currentHp<1 || rolls.length===0 || rolls.some(x=>!Number.isInteger(x)||x<0)) throw new RangeError('invalid KO input');
 const min=Math.min(...rolls),max=Math.max(...rolls);
 if(max===0) return {kind:'impossible'};
 const earliestHits=Math.ceil(currentHp/max);
 if(min>0 && Math.ceil(currentHp/min)===earliestHits) return {kind:'guaranteed',hits:earliestHits};
 const chance=earliestKoChance(rolls,currentHp,earliestHits);
 return {kind:'random',earliestHits,guaranteedHits:min>0?Math.ceil(currentHp/min):Infinity,
   chanceAtEarliest:{numerator:chance.numerator.toString(),denominator:chance.denominator.toString()}};
}
export function formatKo(ko:KoAnalysis):string {
 if(ko.kind==='impossible') return 'この条件では撃破できない';
 if(ko.kind==='guaranteed') return `確定${ko.hits}発`;
 const c={numerator:BigInt(ko.chanceAtEarliest.numerator),denominator:BigInt(ko.chanceAtEarliest.denominator)};
 return `乱数${ko.earliestHits}発(${percentageOneDecimal(c)})`;
}
