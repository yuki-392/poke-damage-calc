/** First working damage pipeline. Does NOT implement every Champions move/ability/item.
 * Unknown or context-dependent effects are never silently treated as neutral.
 * Order/rounding follows the user-specified Champions Wiki; golden game-oracle
 * verification remains outstanding.
 */
import type { AttackMove, Build, DamageRequest, DamageResult, StatId } from './contracts';
import { statAt50, applyStatStage, bareBaseDamageAt50 } from './primitives';
import { isPokemonType, typeEffectiveness, type PokemonType } from './type-chart';
import { analyzeKo } from './ko';

export const RULE_VERSION = 'champions-reference-phase1-1.1.0';
type NonHPStat = Exclude<StatId,'hp'>;
export type AbilityDamageEffect = 'neutral' | 'adaptability' | 'technician' | 'huge-power' | 'guts' | 'filter' | 'multiscale';
export type ItemDamageEffect = 'neutral' | 'life-orb';
export interface FormData {
  id:string;
  types:readonly PokemonType[];
  baseStats:Record<StatId,number>;
  allowedAbilities:readonly string[];
  isMega?:boolean;
  megaRequiredItemId?:string;
}
export interface MoveData extends AttackMove {
  power:number|null;
  effect:'standard' | 'variable-power' | 'fixed-damage' | 'multi-hit' | 'other';
}
export interface MasterCatalog {
  version:string;
  forms:Readonly<Record<string,FormData>>;
  moves:Readonly<Record<string,MoveData>>;
  abilities:Readonly<Record<string,AbilityDamageEffect | 'unsupported'>>;
  items:Readonly<Record<string,ItemDamageEffect | 'unsupported'>>;
}

function roundHalfDownFixed(n:number,factor:number):number {
 // Damage phases use 五捨五超入: integer fraction == 0.5 rounds DOWN.
 const product=n*factor;
 return Math.floor(product/4096) + (product%4096>2048?1:0);
}
function roundHalfUpFixed(n:number,factor:number):number {
 // Intermediate 4096-based modifier composition uses 四捨五入.
 return Math.floor((n*factor+2048)/4096);
}
function invalid(...fields:string[]):DamageResult {
 return {status:'invalid',fields,explanation:'入力値と参照データの整合性を確認してください'};
}
function unsupported(...codes:string[]):DamageResult {
 return {status:'unsupported',codes,explanation:'この条件には未対応の効果または不足している情報があります'};
}
function isValidBuild(b:Build,f:FormData): boolean {
 const ids:StatId[]=['hp','attack','defense','spAttack','spDefense','speed'];
 if(!Array.isArray(f.types) || f.types.length<1 || f.types.length>2 || new Set(f.types).size!==f.types.length || f.types.some(x=>!isPokemonType(x))) return false;
 if(!['none','burn','poison','badPoison','paralysis','sleep','freeze'].includes(b.status)) return false;
 if(ids.some(k=> !Number.isInteger(b.statPoints?.[k]) || b.statPoints[k]<0 || b.statPoints[k]>32 ||
    !Number.isInteger(f.baseStats[k]) || f.baseStats[k]<1 || f.baseStats[k]>255)) return false;
 if(ids.reduce((sum,k)=>sum+b.statPoints[k],0)>66) return false;
 if(ids.filter(k=>k!=='hp').some(k=>![0.9,1,1.1].includes(b.nature[k as NonHPStat]))) return false;
 if(!Number.isInteger(b.currentHp) || b.currentHp<1 || b.currentHp>statAt50('hp',f.baseStats.hp,b.statPoints.hp)) return false;
 if(Object.values(b.stages).some(s => !Number.isInteger(s) || s === undefined || s < -6 || s > 6)) return false;
 if(b.abilityId && !f.allowedAbilities.includes(b.abilityId)) return false;
 if(b.isMega!==Boolean(f.isMega)) return false;
 return true;
}
function getStat(b:Build,f:FormData,stat:NonHPStat):number {
 return statAt50(stat,f.baseStats[stat],b.statPoints[stat],b.nature[stat]);
}
function effectiveStage(b:Build,stat:NonHPStat,critical:boolean,isAttacker:boolean):number {
 const s=b.stages[stat]??0;
 if(critical && ((isAttacker&&s<0)||(!isAttacker&&s>0))) return 0;
 return s;
}
function resolveAbility(id:string|null,db:MasterCatalog):AbilityDamageEffect|undefined {
 if(id===null) return 'neutral';
 const value=db.abilities[id];
 return value && value!=='unsupported'?value:undefined;
}
function resolveItem(id:string|null,db:MasterCatalog):ItemDamageEffect|undefined {
 if(id===null) return 'neutral';
 const value=db.items[id];
 return value && value!=='unsupported'?value:undefined;
}
/** The game master-data form must represent the currently selected forme,
 * including post-Mega stats/types when isMega is true. */
export function calculateDamage(req:DamageRequest, db:MasterCatalog):DamageResult {
 if(req.ruleVersion!==RULE_VERSION) return unsupported('rule-version');
 if(req.masterDataVersion!==db.version) return unsupported('master-data-version');
 const a=db.forms[req.attacker.pokemonFormId],d=db.forms[req.defender.pokemonFormId];
 if(!a||!d) return unsupported('missing-form');
 if(!isValidBuild(req.attacker,a)) return invalid('attacker');
 if(!isValidBuild(req.defender,d)) return invalid('defender');
 for(const [build,form] of [[req.attacker,a],[req.defender,d]] as const) {
   if(form.isMega && !form.megaRequiredItemId) return unsupported('mega-required-item-not-configured');
   if(form.isMega && build.itemId!==form.megaRequiredItemId) return invalid('mega-stone');
 }
 const move=db.moves[req.move.moveId];
 if(!move) return unsupported('missing-move');
 if(![move.category,move.moveType,move.scope].every((v,i)=>v===[req.move.category,req.move.moveType,req.move.scope][i])) return invalid('move');
 if(!isPokemonType(move.moveType)) return invalid('moveType');
 if(!['singles','doubles'].includes(req.conditions.format)|| !['none','sun','rain','sand','snow'].includes(req.conditions.weather)||
    !['none','electric','grassy','misty','psychic'].includes(req.conditions.terrain)) return invalid('conditions');
 if(![1,2,3].includes(req.conditions.targetsActuallyHit)||
   (req.conditions.format==='singles' && req.conditions.targetsActuallyHit>1)||
   (move.scope==='single' && req.conditions.targetsActuallyHit>1)||
   (req.conditions.format==='singles' && req.conditions.attackerHelpingHand)) return invalid('conditions.targetsActuallyHit');
 if(move.category==='status') return {status:'nonDamaging',explanation:'変化技のため直接ダメージはありません'};
 if(move.category!=='physical' && move.category!=='special') return unsupported('move-category');
 if(move.effect!=='standard') return unsupported(`move-effect:${move.effect}`);
 if(!Number.isInteger(move.power)||!move.power||move.power<1||move.power>999) return invalid('move.power');
 if(move.scope==='other') return unsupported('move-scope');
 const abilityA=resolveAbility(req.attacker.abilityId,db);
 const abilityD=resolveAbility(req.defender.abilityId,db);
 const itemA=resolveItem(req.attacker.itemId,db),itemD=resolveItem(req.defender.itemId,db);
 const missing=[];
 if(!abilityA) missing.push(`attacker-ability:${req.attacker.abilityId}`);
 if(!abilityD) missing.push(`defender-ability:${req.defender.abilityId}`);
 if(!itemA) missing.push(`attacker-item:${req.attacker.itemId}`);
 if(!itemD) missing.push(`defender-item:${req.defender.itemId}`);
 if(missing.length) return unsupported(...missing);
 // We cannot infer terrain grounding reliably from just a typing when an item, a
 // transient state or a special effect may change it. Ask the caller explicitly.
 if(req.conditions.terrain!=='none' && (typeof req.conditions.attackerGrounded!=='boolean'||typeof req.conditions.defenderGrounded!=='boolean')) return unsupported('grounded-state-required');
 if(Object.keys(req.conditions.moveSpecificConditions||{}).length) return unsupported('move-specific-conditions');
 // The first slice of the engine has no handler for custom stage/ability context.
 const c=req.conditions;
 const effects:string[]=[];
 const attackStat:NonHPStat=move.category==='physical'?'attack':'spAttack';
 const defenseStat:NonHPStat=move.category==='physical'?'defense':'spDefense';
 let power=move.power;
 if(abilityA==='technician' && power<=60){power=roundHalfUpFixed(power,6144);effects.push('technician');}
 if(c.attackerHelpingHand){power=roundHalfUpFixed(power,6144);effects.push('helping-hand');}
 if(c.terrain!=='none') {
   if(c.attackerGrounded && ((c.terrain==='electric'&&move.moveType==='electric') ||
       (c.terrain==='grassy'&&move.moveType==='grass') || (c.terrain==='psychic'&&move.moveType==='psychic'))) {
      power=roundHalfUpFixed(power,5325);effects.push(`${c.terrain}-terrain-boost`);
   }
   if(c.terrain==='grassy'&&c.defenderGrounded&&['earthquake','bulldoze','magnitude'].includes(move.moveId)) {
     power=roundHalfUpFixed(power,2048); effects.push('grassy-ground-move-reduction');
   }
 }
 let atk=applyStatStage(getStat(req.attacker,a,attackStat),effectiveStage(req.attacker,attackStat,c.critical,true));
 let def=applyStatStage(getStat(req.defender,d,defenseStat),effectiveStage(req.defender,defenseStat,c.critical,false));
 if(abilityA==='huge-power' && move.category==='physical'){atk=roundHalfUpFixed(atk,8192);effects.push('huge-power');}
 if(abilityA==='guts' && req.attacker.status!=='none' && move.category==='physical'){atk=roundHalfUpFixed(atk,6144);effects.push('guts');}
 if(c.weather==='sand'&&move.category==='special'&&d.types.includes('rock')){def=Math.floor(def*1.5);effects.push('sand-rock-spdef');}
 if(c.weather==='snow'&&move.category==='physical'&&d.types.includes('ice')){def=Math.floor(def*1.5);effects.push('snow-ice-defense');}
 const effectiveness=typeEffectiveness(move.moveType as PokemonType,d.types);
 const maxHp=statAt50('hp',d.baseStats.hp,req.defender.statPoints.hp);
 if(effectiveness===0) {
   return {status:'ok',outcomes:[{damage:0,weight:16}],minDamage:0,maxDamage:0,
     minPercentOfMaxHp:0,maxPercentOfMaxHp:0,currentHpUsed:req.defender.currentHp,
     knockout:{kind:'impossible'},appliedEffects:['type-immunity'],warnings:[]};
 }
 const base=bareBaseDamageAt50(power,atk,def);
 let start=base;
 const spread=c.format==='doubles'&&c.targetsActuallyHit>1&& (move.scope==='adjacentFoes'||move.scope==='allAdjacent');
 if(spread){start=roundHalfDownFixed(start,3072);effects.push('spread-0.75');}
 if((c.weather==='sun' && move.moveType==='fire')||(c.weather==='rain'&&move.moveType==='water')){
   start=roundHalfDownFixed(start,6144);effects.push('weather-boost');
 } else if((c.weather==='sun'&&move.moveType==='water')||(c.weather==='rain'&&move.moveType==='fire')){
   start=roundHalfDownFixed(start,2048);effects.push('weather-weakening');
 }
 if(c.critical){start=roundHalfDownFixed(start,6144);effects.push('critical');}
 let stab=4096;
 if(a.types.includes(move.moveType as PokemonType)){
   stab=abilityA==='adaptability'?8192:6144;effects.push(abilityA==='adaptability'?'adaptability-STAB':'STAB');
 }
 const burn=req.attacker.status==='burn'&&move.category==='physical'&&abilityA!=='guts';
 let finalMod=4096;
 const addFinal=(factor:number,id:string)=>{finalMod=roundHalfUpFixed(finalMod,factor);effects.push(id);};
 const wall=(move.category==='physical'?c.reflectOnDefenderSide:c.lightScreenOnDefenderSide)||c.auroraVeilOnDefenderSide;
 if(wall&&!c.critical){addFinal(c.format==='doubles'?2732:2048,'screen');}
 if(abilityD==='filter'&&effectiveness>1)addFinal(3072,'filter');
 if(abilityD==='multiscale'&&req.defender.currentHp===maxHp)addFinal(2048,'multiscale');
 if(itemA==='life-orb')addFinal(5324,'life-orb');
 if(c.terrain==='misty'&&c.defenderGrounded&&move.moveType==='dragon')addFinal(2048,'misty-dragon');
 const rolls=Array.from({length:16},(_,i)=>{
   let val=Math.floor(start*(85+i)/100);
   if(stab!==4096)val=roundHalfDownFixed(val,stab);
   val=Math.floor(val*effectiveness);
   if(burn)val=roundHalfDownFixed(val,2048);
   if(finalMod!==4096)val=roundHalfDownFixed(val,finalMod);
   return Math.max(1,val);
 });
 if(burn)effects.push('burn');
 const min=Math.min(...rolls),max=Math.max(...rolls);
 const frequency=new Map<number,number>();for(const dmg of rolls)frequency.set(dmg,(frequency.get(dmg)||0)+1);
 return {status:'ok',outcomes:[...frequency].map(([damage,weight])=>({damage,weight})),
   minDamage:min,maxDamage:max,minPercentOfMaxHp:min/maxHp*100,maxPercentOfMaxHp:max/maxHp*100,
   currentHpUsed:req.defender.currentHp,knockout:analyzeKo(rolls,req.defender.currentHp),
   appliedEffects:effects,warnings:[]};
}
