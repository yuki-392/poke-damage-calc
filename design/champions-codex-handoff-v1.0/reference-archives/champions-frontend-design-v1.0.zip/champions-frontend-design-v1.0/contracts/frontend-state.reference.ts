/**
 * FRONTEND STATE CONTRACT — DESIGN REFERENCE ONLY (2026-10-23)
 * NOT AN IMPLEMENTATION. Not intended to be imported by the shipping app as-is.
 * Synchronize definitive DTO shapes with API/DB design and damage-engine v1.2.
 */
export type BattleFormat = 'singles' | 'doubles';
export type StatId = 'hp' | 'attack' | 'defense' | 'spAttack' | 'spDefense' | 'speed';
export type NonHpStat = Exclude<StatId, 'hp'>;
export type NatureFactor = 0.9 | 1.0 | 1.1;
export type MoveSlot = string; // canonical moveId; learned/nonlearned status is derived
export type BuildOrigin = 'measured' | 'estimated' | 'custom' | 'manual' | 'incomplete';

export interface SourceVersions {
  schemaVersion: string;
  ruleVersion: string;
  masterDataVersion: string;
  effectCatalogVersion: string;
  regulationId: string;
}

export type ItemEntry =
  | { kind: 'known'; itemId: string }
  | { kind: 'customText'; text: string }
  | { kind: 'none' };

export type EditValidity =
  | { kind: 'valid' }
  | { kind: 'invalidDraft'; fieldPaths: readonly string[]; reason: string }
  | { kind: 'missingContext'; fields: readonly string[] };

export type StatusCondition =
  | 'none' | 'burn' | 'poison' | 'badPoison'
  | 'paralysis' | 'sleep' | 'freeze';

/** All six stats remain in state even when the UI displays only one/two. */
export interface PokemonBuildDraft {
  pokemonFormId: string;
  statPoints: Readonly<Record<StatId, number>>;
  natureId?: string; // historical/measured set provenance, never displayed as nature name
  natureFactors: Readonly<Record<NonHpStat, NatureFactor>>;
  abilityId: string | null; // must be legal for selected form
  item: ItemEntry;
  isMega: boolean;
  currentHp: number | null;
  stages: Readonly<Record<NonHpStat, number>>;
  status: StatusCondition;
  origin: BuildOrigin;
  validity: EditValidity;
}

/** UI context; adapt to a versioned discriminated-union engine context. */
export type Weather = 'none' | 'sun' | 'rain' | 'sand' | 'snow';
export type Terrain = 'none' | 'electric' | 'grassy' | 'misty' | 'psychic';

export interface BattleContextDraft {
  weather: Weather;
  terrain: Terrain;
  targetsActuallyHit: 1 | 2 | 3;
  critical: boolean;
  helpingHand: boolean;
  reflectOnDefenderSide: boolean;
  lightScreenOnDefenderSide: boolean;
  auroraVeilOnDefenderSide: boolean;
  attackerGrounded: boolean | null;
  defenderGrounded: boolean | null;
  /** Extended typed effects are defined in engine rule catalog; never arbitrary unvalidated numbers. */
  supplementary: ReadonlyArray<
    | { kind: 'allyAbility'; abilityId: string; isActive: boolean }
    | { kind: 'moveEffect'; effectId: string; optionId: string }
    | { kind: 'attackerWeightKg'; kilograms: number }
    | { kind: 'defenderWeightKg'; kilograms: number }
  >;
}

export interface NormalSession {
  format: BattleFormat;
  attacker: PokemonBuildDraft;
  defender: PokemonBuildDraft;
  moves: readonly MoveSlot[]; // from 1 to 4 canonical ids
  conditions: BattleContextDraft;
  sourceVersions: SourceVersions;
  revision: number;
}

export interface Top50Session {
  format: BattleFormat;
  rankingSnapshotId: string | null;
  attacker: PokemonBuildDraft;
  moves: readonly MoveSlot[];
  conditions: BattleContextDraft;
  /** entry-id, not rank or display name */
  defenderOverrides: Readonly<Record<string, PokemonBuildDraft>>;
  sourceVersions: SourceVersions;
  revision: number;
}

/** Store state is instantiated per client session under CalculationSessionProvider. */
export interface Top50Workspace {
  activeFormat: BattleFormat;
  /** Each format retains independent snapshot, attacker, conditions, and overrides. */
  sessions: Partial<Record<BattleFormat, Top50Session>>;
}

export interface CalculatorSessionState {
  normal: NormalSession;
  top50: Top50Workspace;
}

/** Always local to the mounted detail component. NOT persisted in global Zustand. */
export interface Top50DetailDraft {
  detailSessionId: string;
  rankingEntryId: string;
  openedFromMoveId: string;
  selectedMoveId: string;
  localConditions: BattleContextDraft;
  openedAtTop50Revision: number;
}

export type DetailAction =
  | { type: 'selectMove'; moveId: string }
  | { type: 'updateLocalConditions'; value: BattleContextDraft }
  | { type: 'resetToOpenedConditions' }
  | { type: 'clearOnClose' };

/** View filters never change combat conditions. */
export interface Top50ViewPreferences {
  mobileActiveMoveIndex: number;
  search: string;
  sort: 'rank' | 'damageDesc' | 'damageAsc';
  koFilter: 'all' | 'guaranteed1' | 'random1' | 'guaranteed2' | 'random2' | 'threeOrMore';
  attackerPanelOpen: boolean;
  filtersPanelOpen: boolean;
}

/** Persisted snapshots are sanitized: invalid input drafts and UI revisions are excluded. */
export type ValidatedBuild = Omit<PokemonBuildDraft, 'validity'>;
export interface NormalSavedInput {
  format: BattleFormat;
  attacker: ValidatedBuild;
  defender: ValidatedBuild;
  moves: readonly MoveSlot[];
  conditions: BattleContextDraft;
  sourceVersions: SourceVersions;
}
export interface Top50SavedInput {
  format: BattleFormat;
  rankingSnapshotId: string;
  attacker: ValidatedBuild;
  moves: readonly MoveSlot[];
  conditions: BattleContextDraft;
  defenderOverrides: Readonly<Record<string, ValidatedBuild>>;
  sourceVersions: SourceVersions;
}
export type SavedInputSnapshot =
  | { mode: 'normal'; schemaVersion: string; input: NormalSavedInput }
  | { mode: 'top50'; schemaVersion: string; input: Top50SavedInput };

/** Design-only action interface; exact function names can be finalized during implementation. */
export interface SessionActions {
  replaceNormal(next: NormalSession): void;
  replaceTop50(next: Top50Session): void;
  swapNormalSides(): void;
  setTop50DefenderOverride(rankingEntryId: string, build: PokemonBuildDraft): void;
  resetTop50DefenderOverride(rankingEntryId: string): void;
  /** Atomically create a normal session. Does not mutate top50 input. */
  transferTop50DetailToNormal(detail: Top50DetailDraft): { ok: true } | { ok: false; reason: string };
}
