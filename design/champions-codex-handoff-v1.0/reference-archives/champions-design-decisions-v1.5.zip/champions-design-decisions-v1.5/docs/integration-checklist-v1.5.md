# Codex用最終統合チェックリスト — U-04共有期限

このファイルは最終正本パッケージ作成時の差分適用指示であり、適用済み実装を意味しない。

| 対象 | 修正指示 | 完了判定 |
|---|---|---|
| OpenAPI `POST /api/v1/shares` | `expiresAt`を必須のISO8601日時に設定、90日ルール明記 | Schema lint + DTO一致 |
| OpenAPI `GET /api/v1/shares/{token}` | 有効期限前は公開、期限切れ410/404、cache no-store | Expiry/Revocationの契約テスト |
| 共通DTO（TypeScript / Zod） | `expiresAt: string`、所有者向けDTOと公開向けDTOを分離 | Runtime schemaと型一致 |
| DB `shared_calculations` | `created_at`・`expires_at`非NULL、90日固定 | マイグレーションテスト |
| 共有発行Route | 認証、Idempotency-Key、発行日時固定、新規token発行 | 競合・再送テスト |
| 共有取得Route | DBの時計で期限・失効を検査し公開DTOのみ返す | 未認証／境界時刻テスト |
| 共有管理UI | JST日時を表示、失効ボタンは本人のみ | UI/E2Eテスト |
| 共有閲覧UI | 期限切れ/失効/再現不可を取り違えず案内 | 画面テスト |
| ランキング/ルール履歴 | **U-05決定待ち**。90日保持と断定しない | 外部出典・保持許諾の確認 |
| 旧版仕様 | `expiresAt:null` と他の期間を無効化 | 設計文書横断レビュー |
