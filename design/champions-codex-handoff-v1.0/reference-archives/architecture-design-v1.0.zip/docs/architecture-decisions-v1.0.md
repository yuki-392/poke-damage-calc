# 技術選定の判断記録 (ADR) v1.0

更新日：2026-10-23

## ADR-001 Next.js + TypeScriptを採用
- **採用**: Next.js（App Router）、TypeScript strict
- **理由**: UI v0.5のPC/モバイル実装、保存画面と共有URLを1つのアプリで扱える。
- **却下**: 最初からフロント・API・バックエンドを別リポジトリにする構成。初期の運用・開発が複雑になる。

## ADR-002 計算コアをUIから分離
- **採用**: `packages/calc-core` の純粋関数。
- **理由**: 同じルールで通常計算とTOP50を計算し、テストできる。最大200組の計算をサーバー通信なしで繰り返す。
- **留意**: ルールバージョン、特殊技・特性・持ち物の対応表、未対応時の結果状態を保持する。

## ADR-003 Supabase PostgreSQL / Auth / Cronを採用
- **採用**: PostgreSQL・Auth・RLS・Cron。WebはVercel。
- **理由**: 保存・端末間同期・共有、毎朝更新の必要性に合う。
- **比較**: Vercel Hobby Cronは1日1回設定できるが起動時刻が指定時間の範囲内で変動するため、09:30の要件に対してSupabase Cronを優先する。
- **留意**: Supabaseでもジョブ実行の厳密な秒単位保証はしない。

## ADR-004 TOP50はスナップショット方式
- **採用**: 形式別にランキングと代表型の有効なスナップショットを保持。表示時はactive IDで参照。
- **理由**: データ欠損・更新失敗が一覧へ混入しない。
- **留意**: API側のランキング取得方法は最初に検証する。生データの永久ミラーを作らない。

## ADR-005 TOP50詳細は一時的な戦闘条件
- **採用**: 詳細内の技・戦闘条件はコピーして独立管理、閉じれば破棄。
- **例外**: 対象ポケモンの型の編集だけはTOP50一覧の個別設定に残す。
- **理由**: ユーザーが決定したUI v0.5の仕様を保つ。

## ADR-006 共有URLはサーバー保管のスナップショット
- **採用**: `/share/[token]` と設定データ。
- **理由**: 大きなTOP50の設定をURLクエリに詰めず、URLを見れば同じ状態を取り出せる。
- **留意**: 元データ・ルールの版を保存し、公開情報の範囲を厳密に限定する。

## ADR-007 未対応効果・不正能力値は静かに無視しない
- **採用**: `invalid-input` / `unsupported-effect` を結果の状態として扱う。
- **理由**: 不正な実数値や未登録持ち物で、もっともらしい誤ったダメージを表示しない。

## 参照元
- https://nextjs.org/docs/app
- https://supabase.com/docs/guides/cron
- https://supabase.com/docs/guides/database/postgres/row-level-security
- https://vercel.com/docs/cron-jobs/usage-and-pricing
- https://championsbattledata.com/api_guide
- https://championsbattledata.com/api-rules/
