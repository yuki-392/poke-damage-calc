# Pokémon Champions ダメージ計算アプリ — 製品仕様決定 v1.4

ユーザー承認済みの決定 **U-03「共有URL発行はログイン必須、閲覧はログイン不要」** を設計契約化した差分パック。

- `docs/U-03-share-access-v1.4.md` — 決定内容、UI・API・DB認可、テスト仕様
- `docs/resolution-register-update-v1.4.md` — 横断レビューの決定・保留状況

このパックは設計のみであり、実装・本番DB変更は含まない。

依存する既存正本:
- U-01: `champions-design-decisions-v1.2/docs/U-01-legal-natures-v1.2.md`
- U-02: `champions-design-decisions-v1.3/docs/U-02-auth-method-v1.3.md`
- 更新方式・共通DTO: `champions-design-reconciliation-v1.1`

次の未決定事項 U-04 は「共有URLの有効期限と参照する過去ランキングの保持期間」。
