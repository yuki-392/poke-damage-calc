# Pokémon Champions DB統合設計 v1.2

UI v0.5、API v1.0、状態管理 v1.0、更新ポリシー v1.2を整合させた**設計資料（非実装）**。

| ファイル | 用途 |
|---|---|
| `docs/database-consolidated-v1.2.md` | 正本：テーブル/関係/版/ランキング公開設計 |
| `docs/security-transactions-and-update-v1.2.md` | RLS/権限/毎時ジョブ/トランザクション |
| `docs/migration-test-and-handoff-v1.2.md` | Codexに対するmigration契約と受け入れテスト28件 |
| `docs/decisions-and-gates-v1.2.md` | 採用判断と、最終レビューまでに解消するゲート |

**重要:** SQLマイグレーションは作成/実行していない。過去の001/002 SQLはドラフトであり新DBの正本ではない。実装時に統合baselineを新規生成する。

関連正本: `champions-frontend-design-v1.0`、`champions-api-integration-design-v1.0`、`champions-design-amendments/top50-update-policy-v1.2.md`、`screen-design-v0.5.md`。
