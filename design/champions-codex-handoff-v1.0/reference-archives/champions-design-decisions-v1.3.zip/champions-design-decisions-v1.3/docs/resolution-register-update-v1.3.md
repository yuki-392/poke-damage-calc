# 設計レビュー決定レジスタの更新 v1.3

| 項目 | 最新状況 | 正本 |
|---|---|---|
| P0-01 ランキング更新 | 契約レベルで解消。毎時確認・当日公開成功後の外部確認停止 | `champions-design-reconciliation-v1.1/docs/update-schedule-v1.3.md` |
| P0-02 保存DTOの不一致 | 契約レベルで解消、実装への反映は未着手 | `champions-design-reconciliation-v1.1/contracts/` |
| P0-03 性格補正 | A案をユーザー承認済み。内部は合法な性格ID一つ | `champions-design-decisions-v1.2/docs/U-01-legal-natures-v1.2.md` |
| **U-02 ログイン方式** | **B案をユーザー承認済み。Google OAuth＋メールのワンタイム認証リンク** | **`U-02-auth-method-v1.3.md`** |
| U-03 共有発行・閲覧権限 | 未決定（次回確認） | なし |
| U-04 共有URL期限・過去ランキング保存期間 | 未決定 | なし |
| P0-04 マスター出典・権利 | 未検証 | なし |
| P0-05 TOP50のゲーム内順位照合 | 未検証 | なし |
| P0-06 計算ルールの実機照合 | 未検証 | なし |
| P0-08 Codex向け統合正本 | 制作前 | なし |

旧設計の「認証方式は候補段階」という記述は、本ファイルと `U-02` の決定により**認証方式についてのみ superseded**。共有発行権限や期限まで確定したと読み替えないこと。バージョン名は文書変更追跡用で、API wire payload の `payloadSchemaVersion` と混同しないこと。
