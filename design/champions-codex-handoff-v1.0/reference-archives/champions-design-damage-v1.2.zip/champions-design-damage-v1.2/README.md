# Pokémon Champions 設計フェーズ：計算エンジン詳細設計 v1.2

これは**設計成果物**。新しい実装やゲーム内検証は含まない。

## 収録物

- `docs/damage-engine-detailed-design-v1.2.md`: コア契約、効果処理、ダメージ・KOモデル、未確定点。
- `registry/effects-catalog-v1.2.md`: 64種の**候補**効果・特殊技のフェーズ／必要文脈／検証状態。対象のChampions収録可否は未照合。
- `docs/verification-and-test-spec-v1.2.md`: L0～L3の4段階検証と32のテストシナリオ。
- `docs/codex-implementation-contract-v1.2.md`: 後続のUI・API・DB設計への境界とCodex受け渡し条件。

## この成果物の限界

ゲーム内実測を新たに行っていない。候補レジストリは現行ゲームの全効果を網羅したと**主張しない**。単発の乱数と多ターン戦闘を区別しており、複雑な補正の厳密値は要ゴールデンテスト。
