/**
 * Pokémon Champions public API read-only smoke test.
 * Run locally with Node >= 20: node scripts/verify-api.mjs
 * Does not write to a database and does not assert that provider data is official.
 */
const BASE = 'https://eurekaffeine.github.io/pokemon-champions-scraper';
const DATA = 'https://championsbattledata.com';

async function fetchJson(url) {
  const signal = AbortSignal.timeout(15000);
  const res = await fetch(url, {signal, headers: {'Accept': 'application/json'}});
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

const rows = [];
for (const [format, path] of [
  ['singles', '/singles/battle_meta.json'],
  ['doubles', '/battle_meta.json'],
]) {
  const url = `${BASE}${path}`;
  try {
    const result = await fetchJson(url);
    const list = result.pokemon_usage;
    if (!Array.isArray(list)) throw new Error('pokemon_usage is not array');
    const first50 = list.slice(0,50);
    const ranks = first50.map(x=>x.rank);
    const ids = first50.map(x=>String(x.dex_id));
    const valid = first50.length === 50 &&
      ranks.every((r,i)=>r===i+1) && new Set(ids).size===50;
    rows.push({source:'battle-meta', format, status:valid?'pass':'schema-warning', count:list.length,
      top50: first50.length, updatedAt:result.updated_at ?? null,
      season:result.season?.id ?? null, sourceUrl:url});
  } catch(e) { rows.push({source:'battle-meta', format, status:'error', message:String(e), sourceUrl:url}); }
}
for (const format of ['Singles','Doubles']) {
  const url = `${DATA}/api/battle/${format}/garchomp`;
  try {
    const result = await fetchJson(url);
    const categories = [...new Set((result.rows||[]).map(r=>r.category))];
    rows.push({source:'champions-battle-data',format,status:categories.length?'pass':'schema-warning',
      categories, season:result.season ?? null, sourceUrl:url});
  } catch(e) { rows.push({source:'champions-battle-data',format,status:'error',message:String(e),sourceUrl:url}); }
}
console.log(JSON.stringify({checkedAt:new Date().toISOString(),rows},null,2));
if (rows.some(x=>x.status !== 'pass')) process.exitCode = 1;
