# Pokémon Champions ダメージ計算アプリ データベース詳細設計 v1.0

更新日: 2026-10-23 / UI基準 v0.5 / アーキテクチャ基準 v1.1

## 設計思想
- 頻繁なダメージ計算はブラウザの独立したTypeScriptエンジンで処理し、DBには**計算結果のキャッシュを必須保存しない**。
- 統計の取り込みを`staging -> validation -> publish`に分割。公開順位の読取中に50件の一部が欠けないようにする。
- ランキングと代表型の出典・日時・レギュレーション・推定アルゴリズムを保持する。
- ポケモン・フォームの内部IDは正規化し、提供元IDとのマッピングを別テーブルで管理する。
- ユーザー設定はJSONBで、計算エンジンと画面のschemaVersionによって整合性を検証する。非公開データのアクセスはRLSを強制する。
- 順位と統計の取得結果はアプリで必要な最小限のキャッシュに限定。APIの永久ミラーやデータ再配信は避ける。

## テーブル一覧

| テーブル | PK | 主な項目と用途 |
|---|---|---|
| `regulations` | `id` | シーズン・使用可能ルール |
| `pokemon_forms` | `id` | Showdown準拠の内部フォームID、種族値、タイプ、日本語名 |
| `moves`, `abilities`, `items` | `id` | マスターデータ・効果フラグ・バージョン |
| `pokemon_abilities` | `(pokemon_id, ability_id)` | ポケモン固有の特性候補 |
| `pokemon_learnsets` | `(pokemon_id, move_id, regulation_id)` | レギュレーション別習得技候補 |
| `data_sources` | `id` | 統計提供元、出典URL、利用条件URL |
| `source_pokemon_ids` | `(source_id, external_id)` | 外部IDと内部フォームIDの対応表 |
| `ingest_runs` | `id` | 9:30更新の成功・失敗・不変・警告 |
| `ranking_snapshots` | `id` | 種別、出典、集計日時、取得日時、状態 |
| `ranking_entries` | `(snapshot_id, rank)` | 順位、フォームID、使用率（不明ならnull） |
| `usage_options` | `id` | 性格、能力ポイント配分、特性、持ち物等の採用統計 |
| `representative_builds` | `(snapshot_id, pokemon_id)` | 実測/推定の区別、6能力ポイント、性格、特性、持ち物 |
| `active_rankings` | `format` | 現在公開するシングル・ダブルのsnapshot参照 |
| `saved_calculations` | `id` | owner、モード、入力JSON、revision、schemaVersion |
| `shared_calculations` | `id` | 非公開のtoken hash、共有用の条件スナップショット、有効期限、失効状態 |

## リレーション図

```mermaid
erDiagram
  REGULATIONS ||--o{ RANKING_SNAPSHOTS : specifies
  DATA_SOURCES ||--o{ RANKING_SNAPSHOTS : produces
  DATA_SOURCES ||--o{ SOURCE_POKEMON_IDS : maps
  POKEMON_FORMS ||--o{ SOURCE_POKEMON_IDS : canonical
  POKEMON_FORMS ||--o{ POKEMON_ABILITIES : has
  ABILITIES ||--o{ POKEMON_ABILITIES : eligible
  POKEMON_FORMS ||--o{ POKEMON_LEARNSETS : learns
  MOVES ||--o{ POKEMON_LEARNSETS : available
  REGULATIONS ||--o{ POKEMON_LEARNSETS : permitted
  RANKING_SNAPSHOTS ||--|{ RANKING_ENTRIES : contains
  POKEMON_FORMS ||--o{ RANKING_ENTRIES : ranked
  RANKING_ENTRIES ||--o{ USAGE_OPTIONS : statistics
  RANKING_ENTRIES ||--o| REPRESENTATIVE_BUILDS : represented
  RANKING_SNAPSHOTS ||--o| ACTIVE_RANKINGS : selected
  USERS ||--o{ SAVED_CALCULATIONS : owns
  USERS ||--o{ SHARED_CALCULATIONS : owns
```

## データ制約の要点
- `ranking_entries.rank` は1〜50で同一snapshot内に重複できない。同一ポケモンフォームも重複禁止。
- 使用率は`NULL`を許容する。ゲーム内で順位のみ公開しているケースの`usage_rate=0`は、**0%と解釈せずNULLに正規化**する。
- `representative_builds` の能力ポイントは各0〜32、合計<=66。`build_kind = 'estimated'`のときアルゴリズム版を必須とする。
- 代表型を実測と呼べるのは**全項目の同時採用頻度が確認できた場合だけ**。各項目のトップを組み合わせた場合は必ず`estimated`。
- `active_rankings` には双方の形式の公開snapshotへのポインタだけを置き、一括更新する。公開用の読み取りAPIは片側の部分取得を避け、単一の整合したレスポンスを返す。
- 保存設定は攻撃側/防御側、戦闘条件、最大4技、TOP50個別オーバーライド、バージョンを持つJSONB。UIの詳細内の一時条件は**保存されるまで一覧の共通条件を上書きしない**。
- 実数値が手入力されて能力ポイントを逆算できない場合、保存JSONの値は `null` と明示し、画面では `?` を表示する。整数カラムの正常な代表型とは分離する。

## 保存/共有 JSON 例（フィールド名は暫定）

```json
{
  "schemaVersion": 1,
  "mode": "top50",
  "format": "singles",
  "regulationId": "mc",
  "rulesetVersion": "champions-v1",
  "rankingReference": { "source": "source-key", "capturedAt": null },
  "attacker": { "pokemonId": "garchomp", "attackPoints": 32, "natureMultiplier": 1.1, "moveIds": ["earthquake", "dragonclaw"] },
  "commonBattlefield": { "weather": "none", "terrain": "none", "flags": [] },
  "defenderOverrides": { "rank-1-pokemon-id": { "hpPoints": 32, "defensePoints": 32 } }
}
```

※ これは構造例であり、現在の実ランキング、技習得可否、合法な合計能力ポイントを保証するサンプルではない。

## 更新処理 (9:30 JST)
1. Cronから認証付きEdge Functionを1回起動。`ingest_runs`のJST日付にユニーク制約を置き、二重起動でも追加取得しない。
2. 順位を取得、`ranking_snapshots`と`ranking_entries`へ`staging`状態で入れる。
3. TOP50の外部IDを正規化し、形態が特定できない行をエラーにする。
4. シングル・ダブル各50件、ユニーク順位、レギュレーションを検証。
5. 各ポケモンの統計・推定代表型を作成。統計項目が不足する場合は`incomplete`を明示。
6. 両形式が成功したときに**1トランザクションで** `active_rankings` の2行を更新。
7. `ingest_runs`に終了時刻・結果・元データの集計日時を残す。失敗した場合は従前の公開参照を維持。
8. `unchanged`なら更新を行わず、実際の出典取得日時は書き換えない。

※ SQL migrationは**初期スキーマの参考実装**。実行ジョブ・API Adapter・publishトランザクションはまだ実装していない。Supabase環境へ適用する前にmigrationとRLSの統合テストが必要。

## セキュリティ設計
- `saved_calculations` はRLSで `owner_id = auth.uid()` の場合だけ `SELECT / INSERT / UPDATE / DELETE` 許可。
- 統計・ランキング・更新履歴には一般ロールからの直接SELECTを許さない。Next.js側で必要最小限の公開レスポンスを生成する（内部更新はservice_role権限で実行）。
- `shared_calculations` も匿名ユーザーには直接SELECT不可。共有URLの高強度ランダムトークンをサーバーでハッシュ照合して、必要な入力条件だけを返す。
- サーバーのservice_roleキーはブラウザへ露出させない。共有URLにログインや個人情報を含めない。
- 共有リンクはユーザー単位の認可・失効・有効期限を持つ。共有生成の認証必須は現在の設計上の仮置き（最終仕様未確定）。
- JSONBの中身には型検証（Zod等）、最大ペイロード量、埋込フィールドのホワイトリストが必要。

## 性能/維持コスト
- ランキング一覧は公開用の集約済み50件データを1回取得。50回のAPI個別アクセスをページ表示ごとにしない。
- 検索対象のポケモン・技・持ち物・特性マスターはアプリビルド時の静的JSON/キャッシュに適宜分離する。
- `ranking_entries(snapshot_id,rank)` と `usage_options(snapshot_id,pokemon_id,category)` にインデックス。
- 更新で参照可能な古いsnapshotを保持しすぎない。合理的な短期キャッシュを基本とし、外部ライセンスが許す範囲を確定後に保持期間を設定する。

## 未決定/実装前に決めること
- フォルム基準データと正規化辞書の出典と更新責任。
- ゲーム内順位を両形式で取得する手段と利用許可。
- ユーザー共有URLの期限・ログイン要否。共有時の統計データの複製範囲（外部提供者との条件整合）。
- 再推定時のアルゴリズムVersionとエラー時の代替設定。
- 統計キャッシュの具体的な保持期間。
