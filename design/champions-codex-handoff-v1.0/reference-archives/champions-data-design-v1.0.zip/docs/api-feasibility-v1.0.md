# Pokémon Champions TOP50データ取得の技術検証 v1.0

更新日: 2026-10-23 / 判定: **条件付きで実現可能。外部APIの実測結合テストは未完了。**

## 目的・前提
- 使用率TOP50をシングル・ダブル別に各50件表示する。ゲーム内の「バトルデータ」に由来する順位を優先する。
- 原則9:30 JSTに1回だけ取得を試みる。取得失敗時に自動再試行しない。
- 育成型は完全な組合せの実測があれば `observed`、なければ `estimated` とする。推定値を「最多採用の実測型」と呼ばない。
- 本資料の確認は公開ガイド、公開Web画面、公開GitHubコードの確認による。**ライブJSONの全件取得・パース・Top50の自動照合は、この環境では完了していない。**

## 検証マトリクス

| 項目 | Champions Battle Data (CBD) | eurekaffeine Champions Battle Meta | 判定 |
|---|---|---|---|
| シングル・ダブルの順位 | `/meta/singles/` と `/meta/doubles/` に表示。`data/builder/meta-*.json` はリポジトリREADMEに記載 | `singles/battle_meta.json` と `battle_meta.json` に `pokemon_usage[].rank` | ドキュメント上可 |
| ゲーム内順位との一致 | 収集したラダー等の由来を要照合 | SinglesはMunchStatsのゲーム内収集順位。DoublesはPikalytics使用率から算出 | 両形式の同一出所は未達 |
| ポケモンごとの技等 | `GET /api/battle/{Singles|Doubles}/{showdown_id}`。`category`, `rank`, `percentage_value` | `pokemon/{dex_id}.json`, `singles/pokemon/{dex_id}.json` に技・持ち物・特性等 | 文書上可 |
| 性格・能力ポイント | CBDのbattle CSVに`stat_up`, `stat_down`, `hp_points`等を記述 | Singlesはデータ元に存在、DoublesはREADMEに将来拡充と記載 | CBDを第1候補 |
| 完全な最多採用「組合せ」 | 個別統計は確認。組合せ頻度は未確認 | READMEの説明では確認できず | `estimated`が基本 |
| レギュレーション | currentと日別/シーズン別データ | season.id, format_code, data_date | 必ず出典を保持 |
| ライセンス | API利用規約に出典表示、適切なキャッシュ、データサービスとしての再配布禁止 | 公開リポジトリはMIT表記。元データの二次利用条件は別途確認 | 実装前に規約最終確認 |

### 確認したエンドポイント

CBD:
- https://championsbattledata.com/api_guide
- https://championsbattledata.com/api
- https://championsbattledata.com/api/battle/Singles/garchomp
- https://championsbattledata.com/api/battle/Doubles/garchomp
- https://championsbattledata.com/meta/singles/
- https://championsbattledata.com/meta/doubles/

eurekaffeine:
- https://eurekaffeine.github.io/pokemon-champions-scraper/singles/battle_meta.json
- https://eurekaffeine.github.io/pokemon-champions-scraper/battle_meta.json
- https://eurekaffeine.github.io/pokemon-champions-scraper/singles/pokemon/445.json
- https://eurekaffeine.github.io/pokemon-champions-scraper/pokemon/445.json
- https://github.com/eurekaffeine/pokemon-champions-scraper/blob/main/README.md

比較元:
- https://www.munchstats.com/about/

## 実装判断

1. **ランキングアダプタ**：ゲーム内順位に由来するデータを第一優先。現時点で eurekaffeine Singles は出典が明示される。Doubles は同APIでもPikalytics由来の推定順位であるため、ゲーム内順位が取得できる別ソースと照合する。ランキング出所を画面上で明記。
2. **統計アダプタ**：CBDの `/api/battle/...` を優先し、各ポケモンの個別採用統計と能力ポイント配分を取得する。互換性のないシーズン・集計期間を混ぜない。混合が不可避なら推定型としてソース内訳を記録する。
3. **ID正規化**：データ取得元の `dex_id` は必ずしも全国図鑑番号ではない。フォーム固有IDやShowdown IDを内部の `pokemon_forms.id` に対応させ、未対応は静かに別フォームへ変換しない。
4. **同時公開**：シングル・ダブルとも50件と代表型データの検証に成功したときだけ、トランザクションで両方の公開ポインタを切り替える。片側に失敗した場合は公開状態を維持する。
5. **日時の区別**：`attempted_at`、`fetched_at`、`source_captured_at` を分離。ソースの更新が変わらない場合は成功扱いの `unchanged` でよい。
6. **再配布の抑制**：APIのrawレスポンスをそのまま配信しない。表示に必要な上位50件と代表型だけをアプリ用APIから返す。履歴キャッシュの保持期間を短くし、公開データサービスを構築しない。

## 9:30更新時刻の注意
- Supabase Cron: `30 0 * * *`（UTCの0:30＝JSTの9:30）。サーバー側のUTCスケジュール設定を確認する。
- eurekaffeineの公開GitHub Actionsは `0 2 * * *`（UTC2:00＝JST11:00）。このデータを9:30に確認してもその日の更新がまだない場合がある。
- 9:30「実行」は最新データの保証を意味しない。次回日までの更新遅れは要求どおり許容する。別途再試行しない。

## 開発開始時に実行する結合テスト（未実施）

| ID | 実施内容 | 合格条件 |
|---|---|---|
| POC-01 | 4つのランキングURLをHTTP取得 | JSON、200、リクエストタイムアウト内 |
| POC-02 | 両形式の `pokemon_usage` の件数・重複・1〜50位 | 50件以上、同順位・重複フォームなし |
| POC-03 | 50件の外部IDと内部フォームIDを結合 | 50件すべて対応。未知フォームは明示して失敗 |
| POC-04 | CBDから任意の上位10匹のbattle rowsを取得 | 性格・配分・特性・持ち物のカテゴリを判別可能 |
| POC-05 | 同じレギュレーション・統計基準日か照合 | 不一致時は別ソースとして明示し、実測型にしない |
| POC-06 | 組み合わせ型の頻度を取得可能か確認 | 取得できない場合は `estimated` へフォールバック |
| POC-07 | 50匹の代表型を決定 | 形式と制約に合う、0〜32/合計66以下 |
| POC-08 | 9:30に同一元データを取得 | `unchanged`・既存公開データを維持 |
| POC-09 | 片方の形式が失敗 | 両方とも公開ポインタを変更しない |
| POC-10 | 引用・規約 | 使用ページでソース名とリンクを表示、許諾範囲を確認 |

## 主な未確定事項
- 最終的にDoublesの「ゲーム内順位」をどの取得元で採用するか。外部使用率の順位を暫定採用する場合、UIラベルに明記が必要。
- API実レスポンスのフィールド・フォームマッピング・日付の整合性。
- 外部由来ランキング・統計のキャッシュ・保存・共有スナップショットが各提供元の利用条件に適合するか。
- CBDの完全採用型の同時頻度が取得可能か。

## 参照
- CBD API Guide: https://championsbattledata.com/api_guide
- CBD API Usage Rules: https://championsbattledata.com/api-rules/
- CBD public repo: https://github.com/Gheist23/pokemonbattledata
- eurekaffeine README: https://github.com/eurekaffeine/pokemon-champions-scraper/blob/main/README.md
- eurekaffeine Actions cron: https://github.com/eurekaffeine/pokemon-champions-scraper/blob/main/.github/workflows/scrape.yml
- MunchStats FAQ: https://www.munchstats.com/about/
