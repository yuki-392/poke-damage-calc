-- Pokémon Champions damage calculator: proposed initial Supabase/PostgreSQL schema.
-- DRAFT: not executed against a live Supabase project. Review, run migrations locally,
-- test RLS, and verify licensing before production use.

create extension if not exists pgcrypto;

create table public.regulations (
  id text primary key,
  label text not null,
  starts_on date,
  ends_on date,
  created_at timestamptz not null default now()
);

create table public.pokemon_forms (
  id text primary key, -- canonical Showdown-like ID; NOT unqualified national dex number
  national_dex integer,
  name_ja text not null,
  name_en text,
  form_label text,
  type1 text not null,
  type2 text,
  hp smallint not null check (hp between 1 and 255),
  attack smallint not null check (attack between 1 and 255),
  defense smallint not null check (defense between 1 and 255),
  sp_attack smallint not null check (sp_attack between 1 and 255),
  sp_defense smallint not null check (sp_defense between 1 and 255),
  speed smallint not null check (speed between 1 and 255),
  master_version text not null,
  is_selectable boolean not null default true
);

create table public.moves (
  id text primary key,
  name_ja text not null,
  type text not null,
  category text not null check (category in ('physical','special','status')),
  power smallint check (power >= 0),
  accuracy smallint check (accuracy between 0 and 100),
  target text,
  effects jsonb not null default '{}'::jsonb,
  master_version text not null
);
create table public.abilities (
  id text primary key,
  name_ja text not null,
  effects jsonb not null default '{}'::jsonb,
  master_version text not null
);
create table public.items (
  id text primary key,
  name_ja text not null,
  effects jsonb not null default '{}'::jsonb,
  master_version text not null
);

create table public.pokemon_abilities (
  pokemon_id text not null references public.pokemon_forms(id) on delete cascade,
  ability_id text not null references public.abilities(id) on delete cascade,
  primary key (pokemon_id, ability_id)
);
create table public.pokemon_learnsets (
  pokemon_id text not null references public.pokemon_forms(id) on delete cascade,
  move_id text not null references public.moves(id) on delete cascade,
  regulation_id text not null references public.regulations(id),
  primary key (pokemon_id, move_id, regulation_id)
);

create table public.data_sources (
  id text primary key,
  name text not null,
  homepage_url text not null,
  attribution_url text,
  terms_url text,
  notes text,
  created_at timestamptz not null default now()
);
create table public.source_pokemon_ids (
  source_id text not null references public.data_sources(id),
  external_id text not null,
  pokemon_id text not null references public.pokemon_forms(id),
  primary key (source_id, external_id)
);
create index source_pokemon_ids_by_internal_idx on public.source_pokemon_ids(pokemon_id);

create table public.ingest_runs (
  id uuid primary key default gen_random_uuid(),
  scheduled_for_jst date not null unique, -- enforce at most one daily attempt
  attempted_at timestamptz not null default now(),
  completed_at timestamptz,
  outcome text not null default 'running'
    check (outcome in ('running','published','unchanged','failed')),
  detail jsonb not null default '{}'::jsonb,
  error_message text
);

create table public.ranking_snapshots (
  id uuid primary key default gen_random_uuid(),
  format text not null check (format in ('singles','doubles')),
  regulation_id text not null references public.regulations(id),
  source_id text not null references public.data_sources(id),
  ingest_run_id uuid references public.ingest_runs(id),
  provenance text not null check (provenance in ('ingame_rank','external_ladder_rank')),
  source_captured_at timestamptz, -- may be unknown
  source_date_label text, -- e.g. 2026-09 if provider has month resolution only
  fetched_at timestamptz not null default now(),
  content_hash text not null,
  state text not null default 'staging' check (state in ('staging','published','retired')),
  unique (id, format)
);
create index ranking_snapshots_lookup_idx
  on public.ranking_snapshots(format, fetched_at desc);

create table public.ranking_entries (
  snapshot_id uuid not null references public.ranking_snapshots(id) on delete cascade,
  rank smallint not null check (rank between 1 and 50),
  pokemon_id text not null references public.pokemon_forms(id),
  usage_rate numeric(8,6) check (usage_rate is null or usage_rate between 0 and 1),
  primary key (snapshot_id, rank),
  unique (snapshot_id, pokemon_id)
);

-- Keep category-specific statistics distinct from a full observed combination.
create table public.usage_options (
  id bigint generated always as identity primary key,
  snapshot_id uuid not null,
  pokemon_id text not null,
  source_id text not null references public.data_sources(id),
  category text not null check (category in ('nature','spread','ability','item','move','complete_build')),
  option_rank smallint check (option_rank >= 1),
  option_value jsonb not null,
  usage_rate numeric(8,6) check (usage_rate is null or usage_rate between 0 and 1),
  foreign key (snapshot_id, pokemon_id)
    references public.ranking_entries(snapshot_id,pokemon_id) on delete cascade
);
create index usage_options_lookup_idx on public.usage_options(snapshot_id,pokemon_id,category);

create table public.representative_builds (
  snapshot_id uuid not null,
  pokemon_id text not null,
  build_kind text not null check (build_kind in ('observed','estimated','incomplete')),
  hp_points smallint check (hp_points between 0 and 32),
  attack_points smallint check (attack_points between 0 and 32),
  defense_points smallint check (defense_points between 0 and 32),
  sp_attack_points smallint check (sp_attack_points between 0 and 32),
  sp_defense_points smallint check (sp_defense_points between 0 and 32),
  speed_points smallint check (speed_points between 0 and 32),
  nature_id text,
  nature_modifiers jsonb not null default '{}'::jsonb,
  ability_id text references public.abilities(id),
  item_id text references public.items(id),
  algorithm_version text,
  source_details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  primary key (snapshot_id, pokemon_id),
  foreign key (snapshot_id, pokemon_id)
    references public.ranking_entries(snapshot_id,pokemon_id) on delete cascade,
  constraint representative_build_total_points check (
    coalesce(hp_points,0) + coalesce(attack_points,0) +
    coalesce(defense_points,0) + coalesce(sp_attack_points,0) +
    coalesce(sp_defense_points,0) + coalesce(speed_points,0) <= 66
  ),
  constraint representative_estimated_version check (
    build_kind <> 'estimated' or (algorithm_version is not null and length(algorithm_version) > 0)
  )
);

-- Read pointer rows within a single transaction to prevent publication of partial updates.
create table public.active_rankings (
  format text primary key check (format in ('singles','doubles')),
  snapshot_id uuid not null,
  activated_at timestamptz not null default now(),
  foreign key (snapshot_id, format) references public.ranking_snapshots(id, format)
);

create table public.saved_calculations (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (length(title) between 1 and 100),
  mode text not null check (mode in ('normal','top50')),
  payload_schema_version integer not null check (payload_schema_version > 0),
  calculation_payload jsonb not null,
  revision bigint not null default 1 check (revision >= 1),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint saved_payload_object check (jsonb_typeof(calculation_payload) = 'object'),
  constraint saved_payload_limit check (octet_length(calculation_payload::text) <= 250000)
);
create index saved_calculations_by_user_idx
  on public.saved_calculations(owner_id, updated_at desc);

-- Only trusted server code knows the random link token and stores its SHA256 hash.
-- Client access: owner SELECT only. Shared-link lookup occurs in an authenticated server endpoint.
create table public.shared_calculations (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  token_hash text not null unique check (length(token_hash) = 64),
  source_calculation_id uuid references public.saved_calculations(id) on delete set null,
  payload_schema_version integer not null check (payload_schema_version > 0),
  share_payload jsonb not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz,
  revoked_at timestamptz,
  constraint shared_payload_object check (jsonb_typeof(share_payload) = 'object'),
  constraint shared_payload_limit check (octet_length(share_payload::text) <= 250000)
);
create index shared_calculations_owner_idx on public.shared_calculations(owner_id, created_at desc);

-- Optimistic concurrency: caller updates with WHERE id=? AND revision=old_revision;
-- no row updated => conflict. Trigger increments revision atomically.
create or replace function public.bump_saved_calculation_revision()
returns trigger language plpgsql set search_path = '' as $$
begin
  new.revision := old.revision + 1;
  new.updated_at := now();
  return new;
end;
$$;
create trigger saved_calculations_revision_trigger
before update on public.saved_calculations
for each row execute function public.bump_saved_calculation_revision();

-- All app tables have RLS enabled. Internal tables intentionally have NO public policies;
-- use server code with service credentials and respond with only the allowed minimal app data.
alter table public.regulations enable row level security;
alter table public.pokemon_forms enable row level security;
alter table public.moves enable row level security;
alter table public.abilities enable row level security;
alter table public.items enable row level security;
alter table public.pokemon_abilities enable row level security;
alter table public.pokemon_learnsets enable row level security;
alter table public.data_sources enable row level security;
alter table public.source_pokemon_ids enable row level security;
alter table public.ingest_runs enable row level security;
alter table public.ranking_snapshots enable row level security;
alter table public.ranking_entries enable row level security;
alter table public.usage_options enable row level security;
alter table public.representative_builds enable row level security;
alter table public.active_rankings enable row level security;
alter table public.saved_calculations enable row level security;
alter table public.shared_calculations enable row level security;

-- Public, app-owned master metadata. Provider-supplied IP/assets still require license review.
create policy public_regulations_read on public.regulations
  for select to anon, authenticated using (true);
create policy public_pokemon_forms_read on public.pokemon_forms
  for select to anon, authenticated using (true);
create policy public_moves_read on public.moves
  for select to anon, authenticated using (true);
create policy public_abilities_read on public.abilities
  for select to anon, authenticated using (true);
create policy public_items_read on public.items
  for select to anon, authenticated using (true);
create policy public_pokemon_abilities_read on public.pokemon_abilities
  for select to anon, authenticated using (true);
create policy public_learnsets_read on public.pokemon_learnsets
  for select to anon, authenticated using (true);

create policy saved_calculations_owner_select on public.saved_calculations
  for select to authenticated using (owner_id = (select auth.uid()));
create policy saved_calculations_owner_insert on public.saved_calculations
  for insert to authenticated with check (owner_id = (select auth.uid()));
create policy saved_calculations_owner_update on public.saved_calculations
  for update to authenticated
  using (owner_id = (select auth.uid()))
  with check (owner_id = (select auth.uid()));
create policy saved_calculations_owner_delete on public.saved_calculations
  for delete to authenticated using (owner_id = (select auth.uid()));
create policy shared_calculations_owner_select on public.shared_calculations
  for select to authenticated using (owner_id = (select auth.uid()));

-- The following are deliberately not included in SQL migrations:
-- 1) Edge Function to fetch/normalize statistics
-- 2) Atomic publication stored procedure for both formats
-- 3) Server-side shared-link creation/read/revocation with rate limiting
-- 4) Cron job installation (requires deployment secrets and timing confirmation)
-- 5) Provider cache retention policy (subject to license confirmation)
