# Pokémon Champions TOP50 データ取得・DB設計 v1.0

UI仕様: v0.5 / 要件仕様: v0.3 / アーキテクチャ: v1.1

## 内容
- `docs/api-feasibility-v1.0.md`: 公開情報から確認できた外部APIと、未検証事項・採用方針
- `docs/database-design-v1.0.md`: ER図、テーブル、制約、更新フロー、セキュリティ
- `supabase/migrations/202610230001_initial_schema.sql`: PostgreSQL/Supabaseの初期スキーマ案（**まだ環境に適用していない**）
- `scripts/verify-api.mjs`: Node 20+で動く**読み取り専用**APIスモークテスト（本環境での実データ試験は未完了）

## 実行例

```bash
node scripts/verify-api.mjs
```

- このテストはAPIの現在のレスポンスが仕様を満たすかの初期検証です。形式の違いや利用条件の検証が必要です。
- migrationは本番適用しないでください。Supabase CLIによるローカルDB起動、migration適用、RLS・トランザクション検証後に導入します。
- データ提供元の規約を確認し、出典を表示してください。
