# Pokémon Champions — 設計決定 U-05 v1.6

- 作成日: 2026-10-23
- フェーズ: **設計のみ**。DB、API、画面の実装・適用はしていない。
- ユーザー合意: **共有時点のTOP50（順位、代表型、編集内容、計算条件）を再現する**。
- 既決定: U-01合法な性格、U-02 Google+メール認証リンク、U-03発行認証必須・閲覧匿名可、U-04発行から90×24時間。
- 最大の未解決ゲート: メインAPIの履歴保持・共有再表示に関する提供元の許諾。

## 読む順序

1. `docs/U-05-historical-top50-v1.6.md` — 正式な製品仕様と境界条件
2. `docs/source-rights-audit-v1.6.md` — 公式サイトで確認した利用規約と権利確認の結果
3. `docs/contracts-integration-v1.6.md` — API/DB/状態管理の改訂指示
4. `docs/release-gates-and-tests-v1.6.md` — 公開前の条件と受け入れ試験
5. `docs/permission-request-template-v1.6.md` — 提供元へ確認する際の文案
6. `docs/decision-register-v1.6.md` — 最新の意思決定一覧

## 正本の優先順位

U-05に関して、本書は以下の「未決定」「最新TOP50で再計算する」「古い版がなければ現行版に代替する」といった解釈を**上書き**する。
- `champions-design-decisions-v1.5/docs/U-04-share-expiry-v1.5.md` のU-05保留箇所
- `champions-db-final-design-v1.2/docs/database-consolidated-v1.2.md` の保持期限未定箇所
- `champions-api-integration-design-v1.0/` のランキング／共有再現性に関する旧設計

U-04の有効期間90日、U-03の権限など既決定部分は引き続き有効。将来Codex用の統合正本に反映するまでは、過去版のファイルをそのまま横並びで「全て現行仕様」と扱わないこと。

## 重要な注意

APIを使用できることと、過去のランキングを90日間保持して匿名ユーザーへ再表示することは、法的・契約上同義ではない。提供元の確認がない状態で、後者の許諾を得たと書かないこと。本文は法的な許諾の保証ではない。
