# API・DB・React・計算エンジン：U-05統合改訂指示

フェーズ：設計のみ。既存の実装ファイルは上書きしていない。

## 共通DTO

- `SavedInputSnapshot`のTOP50ブランチを固定し、既存v1.1の共通型を唯一の正本として改訂する。表示上の「公開世代」は単一 `rankingPublicationId` に紐付ける。
- `SharedTop50Snapshot` には確定入力（attacker、4技、共通条件、defenderOverrides）と、選択format・regulation・公開版ID・ゲームルール版・マスター版・代表型生成版・参照する出典IDを含める。
- 保存時の`defenderOverrides`のキーは `(snapshotId, rankingEntryId)` を正しく参照し、共有再現時も元の対象へ対応させる。
- サーバーは発行リクエスト中の公開世代IDを検証し、**発行時点で参照している公開世代**を固定する。途中でアクティブ公開ポインタが切り替わっても別世代に混在させない。ユーザーが意図的に旧版を開いている場合、その版を固定する。
- 共有ビューはランク50件と必要最小限の型・表示項目だけを返し、原API全件の転送やダンプ機能は作らない（**この限定だけで許諾を満たすとは判断しない**）。

## API

| Endpoint | 仕様差分 |
|---|---|
| `POST /api/v1/shares` | 認証必須。元のモードがTOP50なら存在・利用許諾・90日再現可能性を検証し、発行時点で版を固定。ライセンス未承認なら `409/403 SOURCE_RIGHTS_UNVERIFIED` 等の適切な4xxで発行しない。 |
| `GET /api/v1/shares/{token}` | 匿名可。期限・失効・権利状況確認後、共有当時のランキング版から50件を復元。現行版への置換禁止。 |
| `GET /api/v1/rankings/active` | 従来どおり**現行公開版**を返す。共有閲覧の過去再現のためにこのAPIを流用しない。 |
| 履歴取得内部処理 | サーバー管理のID参照で過去スナップショットとルール・マスターを読み出す。第三者が任意版を大量取得できる公開ダンプAPIは設けない。 |

エラーの論理カテゴリ：`SHARE_EXPIRED`、`SHARE_REVOKED`、`HISTORICAL_SNAPSHOT_UNAVAILABLE`、`ENGINE_VERSION_UNAVAILABLE`、`SOURCE_RIGHTS_RESTRICTED`。発行時の権利未承認は `SOURCE_RIGHTS_UNVERIFIED`。HTTPコードと型は最終OpenAPIで固定し、共有トークンが外部ログに漏れないようにする。

## DB

1. 既存 `ranking_publications`、`ranking_snapshots`、`ranking_entries`、`representative_builds` を**不変**として保持。発行済み共有の参照先をUPDATEしない。
2. `shared_calculations` に`ranking_publication_id`（top50共有の場合必須）と規定・版の検証可能な参照を持たせる。`share_payload`との二重管理不一致を拒否する。
3. `ranking_publications`/`catalog_versions` の参照元の有効共有最大`expires_at`を計算できる索引または参照テーブルを用意。削除はDBロック/トランザクションで「参照0」を再確認し、並行して共有を新規発行されても必要版が消えないようにする。
4. `source_approvals`は順位定義の承認、`source_rights_grants`（新規の**論理設計**）は保存・表示の権利承認を別々に持つ。具体的なDDLは最終DB baselineの段階で確定。
5. `share_payload`に発行者メールやトークン原文を含めない。トークンはハッシュのみ長期保管。
6. `expires_at`まで共有が生きる間は、必要な版データと計算エンジンのリリースを参照可能にする。各ソースの許諾済み範囲に限る。
7. 外部ソース履歴に権利上の削除指示があれば、それを優先し、参照共有は停止／エラー表示。最新へのサイレント置換なし。
8. 原データ全量の履歴保存や独立した外部データ再配布APIは初期設計に含めない。

## フロントエンド

- 通常計算および現行TOP50編集stateと、共有閲覧の`historicalSnapshot`を分離。共有取得でZustandの現行TOP50のキャッシュを書き換えない。
- 共有ページでは「共有時点のランキング版」「出典」「データ時点」「推定代表型」を表示。共有の攻撃側・技・条件も当時の値。
- 「編集して使う」は読み込んだ確定入力を複製し、別の編集セッションへ移る。ユーザーの明示操作なしに最新TOP50へ切り替えない。
- `getSharedSnapshot()`から受信したルール版は計算エンジンのバージョンルータでロードする。バージョンなしの現行エンジンを使用しない。

## 更新ジョブ

- 毎時確認・更新成功後はその日の外部確認を停止というv1.3方式を維持。
- 更新ジョブは旧版の参照元を上書きしない。最初に新版を作成・検証し、シングル／ダブルの公開ポインタを原子的に切り替える。
- 歴史版の保持・削除ジョブはランキング更新ジョブと別で管理。
