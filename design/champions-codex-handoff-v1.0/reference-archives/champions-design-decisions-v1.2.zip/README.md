# 仕様決定パック v1.2 — U-01

- `docs/U-01-legal-natures-v1.2.md`: ユーザー承認済みA案を具体的な製品仕様として確定。
- `docs/resolution-register-update-v1.2.md`: 横断レビューレジスタの更新。

これは**設計文書のみ**であり、実装・実機検証は含まない。
既存 `champions-design-reconciliation-v1.1` は履歴として保持し、性格の扱いについては本パックの U-01 決定を優先する。
