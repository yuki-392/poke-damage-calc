# Pokémon Champions マスターデータ取得元・品質・利用条件設計 v1.0

- 日付: 2026-10-23
- 対象: P0-04（マスター出典／利用条件／版管理）
- 対象バージョン: 初期公開／設計段階のみ
- 前提: U-06 v1.7 によりURL共有機能は除外済み
- 状態: **データ取得方式の設計は確定候補。各ソースのChampions現行版との全件照合と権利確認は未完了。**

## 読む順番

1. `docs/P0-04-master-data-source-decision-v1.0.md` — マスターの出典優先順位と採否
2. `docs/source-rights-and-attribution-v1.0.md` — 規約・ライセンスと権利処理
3. `docs/catalog-adapters-and-quality-gates-v1.0.md` — 属性値の正規化・型・ゲート
4. `contracts/catalog-field-spec-v1.0.yaml` — データのフィールド契約（設計用）
5. `docs/acceptance-test-matrix-v1.0.md` — 実装後の受け入れ確認
6. `docs/decision-register-update-v1.8.md` — 既存設計との差分と残課題

本資料をゲーム本体の保証済みDB、スクレイピング許可証、ライセンス評価の法的確証として扱わないこと。GitHub等の派生ライセンスがポケモンIP所有者の権利まで許諾することはない。
