# Pokémon Champions TOP50 データ連携検証 v1.1

要件定義v0.3 / UI v0.5 / DB設計v1.0に対する追加検証。

- `docs/api-validation-results-v1.1.md` 実公開JSON4件のスキーマ検証結果
- `docs/database-amendments-v1.1.md` DB設計差分と本番公開の検証ゲート
- `scripts/verify-top50.mjs` ダウンロードまたはローカルJSONファイルによる再検証
- `scripts/ranking-validation.mjs` 構造検証・正規化・推定代表型ラベリング
- `tests/ranking-validation.test.mjs` 単体テスト（Node.js標準テストランナー）
- `supabase/migrations/202610230002_rank_verification.sql` 未検証ランキングの公開をブロックするSQLドラフト

## 動作確認済み

```sh
node --test tests/ranking-validation.test.mjs
```

## 実ネットワーク環境で再検証

```sh
node scripts/verify-top50.mjs
```

ローカルに4つのJSONを配置する場合は、ファイル名を`main-singles.json`、`main-doubles.json`、`alternative-singles.json`、`alternative-doubles.json`にして、`node scripts/verify-top50.mjs --dir ./downloads`。

**重要:** 形式検証が通過しても、ゲーム内バトルデータの実測順位との一致を意味しない。Main providerの`set`は推定代表型としてのみ使用する。
