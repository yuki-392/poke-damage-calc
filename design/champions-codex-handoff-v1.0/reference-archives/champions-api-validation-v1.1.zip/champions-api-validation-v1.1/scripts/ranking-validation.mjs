/**
 * Dependency-free Pokémon Champions public ranking feed validator/normalizer.
 * This file validates structure, not whether the provider matches in-game ranks.
 * Entries with a synthetic 'set' MUST be labelled estimated, never observed.
 */
const canonicalName = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');
const numeric = (v) => typeof v === 'number' && Number.isFinite(v);

export function validateAndNormalize(feed, {provider, format} = {}) {
  const failures = [];
  if (!['battle-data', 'battle-meta'].includes(provider)) throw new TypeError('unknown provider');
  if (!['singles', 'doubles'].includes(format)) throw new TypeError('invalid format');
  const main = provider === 'battle-data';
  const expectedFormat = format === 'singles' ? 'Singles' : 'Doubles';
  const sourceList = main ? feed?.pokemon : feed?.pokemon_usage;
  if (!Array.isArray(sourceList)) return {ok:false,errors:['missing source array'],entries:[],metadata:{provider,format}};
  if (main && feed.format !== expectedFormat) failures.push(`format mismatch: ${feed.format}`);
  if (!main && typeof feed?.season?.format_code !== 'string') failures.push('missing season.format_code');
  if (sourceList.length < 50) failures.push(`less than 50 rows: ${sourceList.length}`);
  const entries = [];
  const keys = new Set();
  for (const [index, row] of sourceList.slice(0,50).entries()) {
    const rank = main ? row.position : row.rank;
    const name = row.name;
    const form = main ? row.form : row.form;
    if (!Number.isInteger(rank) || rank !== index + 1) failures.push(`row ${index + 1}: rank not sequential (${rank})`);
    if (typeof name !== 'string' || !name.trim()) failures.push(`row ${index + 1}: missing name`);
    // IMPORTANT: a National Dex ID alone is NOT unique for Pokémon forms.
    // For the Battle Data manifest, form is a per-Pokémon form name; use name+form.
    const key = main ? `${canonicalName(name)}:${canonicalName(form)}` : `${row.dex_id}:${canonicalName(form ?? name)}`;
    if (keys.has(key)) failures.push(`row ${index + 1}: duplicate form key ${key}`);
    keys.add(key);
    let usageRate = null;
    if (!main && numeric(row.usage_rate)) {
      // Battle Meta singles deliberately uses 0 for unknown, NOT actual 0% usage.
      usageRate = (format === 'singles' && row.usage_rate === 0) ? null : row.usage_rate;
      if (usageRate !== null && (usageRate < 0 || usageRate > 1)) failures.push(`row ${index + 1}: invalid usage rate`);
    }
    let build = null;
    if (main) {
      const points = row.set?.bonuses;
      if (!Array.isArray(points) || points.length !== 6 ||
          !points.every(x => Number.isInteger(x) && x >= 0 && x <= 32) ||
          points.reduce((a,b)=>a+b,0) > 66) failures.push(`row ${index+1}: invalid stat points`);
      if (!row.set?.nature || !row.set?.ability || !row.set?.item) failures.push(`row ${index+1}: incomplete representative set`);
      for (const prop of ['spreads','natures','abilities','items']) {
        if (!Array.isArray(row[prop]) || row[prop].length === 0) failures.push(`row ${index+1}: no ${prop} stats`);
      }
      build = {
        kind:'estimated', // provider set is generated from independently highest ranked categories
        nature:row.set?.nature ?? null,
        ability:row.set?.ability ?? null,
        item:row.set?.item ?? null,
        points:Array.isArray(points)?points:null,
        source:'top-category-per-field',
        // Do not invent whole-build frequency/probability.
        jointUsageRate:null,
      };
    }
    entries.push({rank,name,form:form || null,externalKey:key,usageRate,build});
  }
  const timestamp=main?feed.generatedAt:feed.updated_at;
  if (!timestamp || Number.isNaN(Date.parse(timestamp))) failures.push('invalid generated/updated date');
  return {
    ok:failures.length===0,
    errors:failures,
    metadata:{provider,format,rowCount:sourceList.length,generatedAt:timestamp ?? null,season:feed.season?.id ?? null,
      rankDefinition:main?'provider CSV column_position (not independently verified as in-game)'
        :format==='singles'?'MunchStats screen-capture ordinal (according to provider)':'Pikalytics usage order (NOT game-internal ranking)',
      inGameRankVerified:false},
    entries,
  };
}
