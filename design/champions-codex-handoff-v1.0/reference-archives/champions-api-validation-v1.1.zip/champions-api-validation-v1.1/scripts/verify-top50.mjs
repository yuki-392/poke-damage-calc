#!/usr/bin/env node
/**
 * Run with: node scripts/verify-top50.mjs
 * Or offline: node scripts/verify-top50.mjs --dir ./downloads
 *   downloads/main-singles.json, main-doubles.json, alternative-singles.json,
 *   alternative-doubles.json
 * A nonzero exit code means structural validation failed, NOT that an official
 * in-game comparison has been performed.
 */
import {readFile} from 'node:fs/promises';
import {validateAndNormalize} from './ranking-validation.mjs';

const SOURCES=[
  {filename:'main-singles.json',provider:'battle-data',format:'singles',url:'https://raw.githubusercontent.com/Gheist23/pokemonbattledata/main/data/builder/meta-singles.json'},
  {filename:'main-doubles.json',provider:'battle-data',format:'doubles',url:'https://raw.githubusercontent.com/Gheist23/pokemonbattledata/main/data/builder/meta-doubles.json'},
  {filename:'alternative-singles.json',provider:'battle-meta',format:'singles',url:'https://raw.githubusercontent.com/eurekaffeine/pokemon-champions-scraper/gh-pages/singles/battle_meta.json'},
  {filename:'alternative-doubles.json',provider:'battle-meta',format:'doubles',url:'https://raw.githubusercontent.com/eurekaffeine/pokemon-champions-scraper/gh-pages/battle_meta.json'},
];
const dirIdx=process.argv.indexOf('--dir');
const directory=dirIdx>=0?process.argv[dirIdx+1]:null;
if(dirIdx>=0 && !directory) throw new Error('missing --dir value');

async function fetchJson(def) {
  if (directory) return JSON.parse(await readFile(`${directory}/${def.filename}`,'utf8'));
  const r=await fetch(def.url,{headers:{Accept:'application/json'},signal:AbortSignal.timeout(20000)});
  if(!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}
const summaries=[];
const raw=new Map();
for (const def of SOURCES) {
  try {
    const feed=await fetchJson(def);
    const out=validateAndNormalize(feed,def);
    raw.set(`${def.provider}:${def.format}`,out);
    summaries.push({source:def.provider,format:def.format,url:def.url,ok:out.ok,
      ...out.metadata,top50:out.entries.length,errors:out.errors,
      coverage:out.entries.filter(x=>x.build?.kind==='estimated').length});
  } catch(e) {
    summaries.push({source:def.provider,format:def.format,url:def.url,ok:false,error:String(e)});
  }
}
for (const format of ['singles','doubles']) {
  const a=raw.get(`battle-data:${format}`), b=raw.get(`battle-meta:${format}`);
  if (!a?.ok||!b?.ok) continue;
  const n=x=>String(x).toLowerCase().replace(/[^a-z0-9]/g,'');
  const bNames=new Map(b.entries.map(x=>[n(x.name),x.rank]));
  summaries.push({compare:format,overlapTop50ByEnglishName:a.entries.filter(x=>bNames.has(n(x.name))).length,
    exactRankMatchesAmongMainTop50:a.entries.filter(x=>bNames.get(n(x.name))===x.rank).length,
    note:'Name-level comparison only; forms and regulation must be matched independently before production.'});
}
console.log(JSON.stringify({checkedAt:new Date().toISOString(),source:'Live downloaded feed or supplied JSON files',summaries},null,2));
if(summaries.some(x=>x.ok===false))process.exitCode=1;
