import test from 'node:test';
import assert from 'node:assert/strict';
import {validateAndNormalize} from '../scripts/ranking-validation.mjs';
const mkMain=(format='Singles')=>({format,generatedAt:'2026-10-22T08:44:17.447Z',pokemon:Array.from({length:50},(_,i)=>({
 position:i+1,name:`Poke${i}`,form:`Poke${i}`,
 set:{bonuses:[2,32,0,0,0,32],nature:'Jolly',ability:'Example ability',item:'Example item'},
 spreads:[[35,[2,32,0,0,0,32]]],natures:[['Jolly',60]],abilities:[['Example ability',95]],items:[['Example item',50]]
}))});
const mkAlt=(format='singles')=>({updated_at:'2026-10-22T07:53:43Z',season:{format_code:format},pokemon_usage:Array.from({length:50},(_,i)=>({rank:i+1,dex_id:i+1,name:`Poke${i}`,usage_rate:format==='singles'?0:(50-i)/100}))});
test('main format valid and all provider-built sets remain estimated',()=>{
 const d=validateAndNormalize(mkMain(),{provider:'battle-data',format:'singles'});
 assert.equal(d.ok,true); assert.equal(d.entries.length,50);assert.equal(d.entries[0].build.kind,'estimated');
 assert.equal(d.entries[0].build.jointUsageRate,null);
});
test('invalid points total is rejected',()=>{
 const d=mkMain();d.pokemon[0].set.bonuses=[32,32,32,0,0,0];
 assert.equal(validateAndNormalize(d,{provider:'battle-data',format:'singles'}).ok,false);
});
test('missing or duplicate ranks are rejected',()=>{
 const d=mkMain();d.pokemon[1].position=1;
 assert.equal(validateAndNormalize(d,{provider:'battle-data',format:'singles'}).ok,false);
});
test('duplicate forms are rejected',()=>{
 const d=mkMain();d.pokemon[1].name='Poke0';d.pokemon[1].form='Poke0';
 assert.equal(validateAndNormalize(d,{provider:'battle-data',format:'singles'}).ok,false);
});
test('fewer than 50 entries are rejected',()=>{
 const d=mkMain();d.pokemon.pop();
 assert.equal(validateAndNormalize(d,{provider:'battle-data',format:'singles'}).ok,false);
});
test('singles zero usage maps to unknown, not 0%',()=>{
 const d=validateAndNormalize(mkAlt('singles'),{provider:'battle-meta',format:'singles'});
 assert.equal(d.ok,true);assert.equal(d.entries[0].usageRate,null);
});
test('doubles alternative rate remains proportion',()=>{
 const d=validateAndNormalize(mkAlt('doubles'),{provider:'battle-meta',format:'doubles'});
 assert.equal(d.ok,true);assert.equal(d.entries[0].usageRate,0.5);
});
test('main format mismatch fails',()=>{
 assert.equal(validateAndNormalize(mkMain('Singles'),{provider:'battle-data',format:'doubles'}).ok,false);
});
