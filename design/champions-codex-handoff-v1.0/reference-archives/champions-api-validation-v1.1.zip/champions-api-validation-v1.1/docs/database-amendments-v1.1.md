# データベース設計補足 v1.1

基準: `champions-data-design-v1.0/supabase/migrations/202610230001_initial_schema.sql`。
この資料は差分仕様。`202610230002_rank_verification.sql`は**未実行のドラフト**。

## なぜ設計変更するか

1. JSONの正しい形式と順位の実測一致は別問題。`ranking_snapshots`にゲーム内照合の状態を持たせる。
2. `set`はカテゴリ別の上位採用項目を合成している。`representative_builds.build_kind='estimated'`を必須の取り込みルールとする。
3. 複数APIのデータは定義・取得日時が異なる。出典・生成日時・ファイルSHAを一緒に保持する。
4. Singlesの別APIでの`usage_rate = 0`は実際の使用率0%ではなく「割合の未公開」なので`NULL`へ正規化する。
5. National Dex IDはフォルムに対して一意ではない場合がある。`source_pokemon_ids.external_id`をDex IDだけで構成しない。外部名・フォルムと人間が検証した内部フォームIDを対応づける。

## スナップショットのライフサイクル

```mermaid
flowchart LR
  A[外部JSON取得] --> B[構造チェック]
  B --> C[50件・IDマッピング検証]
  C --> D[stagingで保存]
  D --> E{ゲーム内順位を独立照合済み?}
  E -->|No| F[未検証として保持]
  E -->|Yes| G[verified_ingameへ]
  G --> H[両形式同時に公開]
```

- データ形式の構造チェックと、ゲーム内順位照合を別工程として記録。
- 非同期更新ジョブは2形式に必要な取得・整合性チェックが成功したときだけ公開候補を作る。
- 9:30 JSTに1回試行し、失敗時には既存の公開スナップショットを維持する。
- `provider_generated_at`・`fetched_at`・`ingest_runs.attempted_at`を使い分ける。
- 差分SQLは`active_rankings`の参照先をゲーム内順位検証済みのスナップショットのみに制限するため、未検証データをいきなり本番公開しない。

## 正規化の設計

| 内部項目 | Main provider | 変換ルール |
|---|---|---|
| rank | `pokemon[].position` | 1〜50を確認、順序を勝手に補完しない |
| external form key | `name + form` | 正規化辞書で `pokemon_forms.id`に照合 |
| usage_rate | なし | `NULL` |
| source_generated_at | `generatedAt` | UTCの`timestamptz` |
| set nature | `set.nature` | フル性格IDを保管し、UIでは該当能力の倍率のみ表示 |
| set stat points | `set.bonuses[0..5]` | HP,Atk,Def,SpA,SpD,Speの順 |
| representative build | `set.*` | **estimated**。同時採用率は持たない |
| raw adoption stats | `natures`,`spreads`,`items`,`abilities` | カテゴリ別の採用率として保存 |

### 対応の優先度

- `source_pokemon_ids`のフォームマッピングは「入力された名前がそのまま日本語で出る」前提にしない。
- 同じ図鑑番号の別フォルムを単純に統合しない。
- データが不足する場合は「初期値」や「不明」と明示。数値・採用率を捏造しない。
- マスターデータの種族値はBattle Dataのランキングから無理に生成せず、別の検証済みマスターを使用する。

## セキュリティとデータ保持

- 出典JSON全件をクライアントに再配信する汎用APIは提供しない。
- 公開向けの50件＋必要最低限の統計・代表型だけをアプリに返す。
- API利用条件とキャッシュ期間を最終確認したのち保持期間を確定する。
- Supabase `service_role`をクライアントへ渡さない。

## 本番SQL導入前の検証

1. ローカルPostgreSQLまたはSupabase CLIで初期SQL→差分SQLを順に適用する。
2. 未検証スナップショットへの `active_rankings` の切り替えが失敗すること。
3. `verified_ingame`へ変更した両形式の正しい50件が同一トランザクションで切り替わること。
4. RLSでユーザーAの保存内容がユーザーBに見えないこと。
5. トランザクション途中で失敗したとき旧ランキングが維持されること。

ここでのSQLはあくまで提案であり、実DBへの適用と検証は未実施。
