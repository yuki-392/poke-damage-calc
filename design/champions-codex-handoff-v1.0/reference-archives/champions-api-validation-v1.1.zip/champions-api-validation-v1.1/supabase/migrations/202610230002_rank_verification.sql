-- Draft follow-up migration for initial_schema; NOT applied/tested on Supabase.
-- Its purpose is to distinguish a valid provider feed from a game-verified rank.
-- Ranking publication is denied until a human/independent verification marks
-- both format snapshots verified_ingame.
BEGIN;

ALTER TABLE public.ranking_snapshots
  DROP CONSTRAINT IF EXISTS ranking_snapshots_provenance_check;
ALTER TABLE public.ranking_snapshots
  ADD CONSTRAINT ranking_snapshots_provenance_check
  CHECK (provenance IN ('ingame_rank','external_ladder_rank','unverified_rank'));

ALTER TABLE public.ranking_snapshots
  ADD COLUMN provider_file_sha text,
  ADD COLUMN provider_generated_at timestamptz,
  ADD COLUMN rank_verification text NOT NULL DEFAULT 'unverified'
    CHECK (rank_verification IN ('unverified','verified_ingame','external_ladder')),
  ADD COLUMN rank_verification_note text;

-- Protect the active pointer from inadvertently treating a structurally valid
-- third-party feed as an officially verified game ranking.
CREATE OR REPLACE FUNCTION public.guard_active_ranking_source()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = ''
AS $$
DECLARE
  snapshot_format text;
  snapshot_state text;
  snapshot_provenance text;
  snapshot_verification text;
  entry_count bigint;
BEGIN
  SELECT rs.format, rs.state, rs.provenance, rs.rank_verification
  INTO snapshot_format, snapshot_state, snapshot_provenance, snapshot_verification
  FROM public.ranking_snapshots rs WHERE rs.id = NEW.snapshot_id;

  IF snapshot_format IS DISTINCT FROM NEW.format
    OR snapshot_state IS DISTINCT FROM 'published'
    OR snapshot_provenance IS DISTINCT FROM 'ingame_rank'
    OR snapshot_verification IS DISTINCT FROM 'verified_ingame' THEN
      RAISE EXCEPTION 'Ranking is not verified as in-game for format %', NEW.format;
  END IF;
  SELECT count(*) INTO entry_count FROM public.ranking_entries WHERE snapshot_id=NEW.snapshot_id;
  IF entry_count <> 50 THEN
    RAISE EXCEPTION 'Snapshot has % entries, expected exactly 50', entry_count;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER active_rankings_require_verified_ingame
BEFORE INSERT OR UPDATE OF snapshot_id, format ON public.active_rankings
FOR EACH ROW EXECUTE FUNCTION public.guard_active_ranking_source();

-- Note: after this guard, a publication transaction must:
-- (1) ingest + validate 50 entries, (2) set snapshot state='published',
-- (3) independently confirm game ranking, (4) mark verified_ingame,
-- (5) atomically replace both active pointers.
-- It is NOT enough to verify JSON structure or trust a provider's field name.
COMMIT;
