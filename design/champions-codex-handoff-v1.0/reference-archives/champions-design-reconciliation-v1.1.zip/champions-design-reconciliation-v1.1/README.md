# Pokémon Champions 設計差分解消パック v1.1

2026-10-23 / **設計のみ・実装なし・Codex最終引き渡し前**

このパックは横断レビューP0-01（更新時刻の旧版混在）とP0-02（Frontend/API保存DTO不一致）を**契約レベルで修正**し、P0-08の要求一覧を起こした暫定改訂版。既存ファイルの破壊的上書きではなく、最新版を明示的に採用する。旧ファイルは履歴資料。

- `docs/update-schedule-v1.3.md`: 毎時確認・当日成功停止の統一更新仕様。
- `docs/canonical-contract-v1.1.md`: FE/API/DBのwire format正本。
- `contracts/shared-contract.reference.ts`: 共通DTOの型定義**参考資料**（アプリ実装ではない）。
- `contracts/openapi-v1.1.yaml`: OpenAPI 3.1 の保存/共有API等の厳格化仕様。
- `docs/resolution-register-v1.1.md`: 8個のP0問題の進捗と新旧資料の優先順位。
- `docs/requirements-candidate-v1.0.md`: 要件の正本**候補**（次回承認）。
- `docs/next-decision-U01.md`: 最初のユーザー判断「性格倍率」。
- `qa/validate_design_contract.py`: 設計用JSON Schema整合性テスト。
- `qa/verification-results.md`: 検査結果。

**実装はまだ**: Supabase migration/cron/React/Server route/バトル計算エンジンの変更なし。性格・認証・共有寿命・マスター・ランキング出典も未確定。
