"""Offline contract consistency checks for design reference only; not app code."""
from copy import deepcopy
from pathlib import Path
import yaml
from jsonschema import Draft202012Validator

path=Path(__file__).resolve().parent.parent/'contracts/openapi-v1.1.yaml'
doc=yaml.safe_load(path.read_text())
assert doc['openapi'].startswith('3.1.'),doc['openapi']
root={'$schema':'https://json-schema.org/draft/2020-12/schema','components':{'schemas':doc['components']['schemas']},'$ref':'#/components/schemas/SavedInputSnapshot'}
validator=Draft202012Validator(root)

build={'pokemonFormId':'p25','statPoints':{'hp':6,'attack':20,'defense':0,'spAttack':0,'spDefense':0,'speed':0},'natureId':None,
 'natureFactors':{'attack':1,'defense':1,'spAttack':1,'spDefense':1,'speed':1},'abilityId':None,'item':{'kind':'none'},'isMega':False,
 'currentHp':None,'stages':{'attack':0,'defense':0,'spAttack':0,'spDefense':0,'speed':0},'status':'none','origin':'manual'}
ctx={'weather':'none','terrain':'none','targetsActuallyHit':1,'critical':False,'helpingHand':False,
 'reflectOnDefenderSide':False,'lightScreenOnDefenderSide':False,'auroraVeilOnDefenderSide':False,
 'attackerGrounded':None,'defenderGrounded':None,'supplementary':[]}
vers={'ruleVersion':'r1','masterDataVersion':'m1','effectCatalogVersion':'e1','regulationId':'reg1'}
normal={'payloadSchemaVersion':1,'mode':'normal','input':{'format':'singles','attacker':build,'defender':build,
  'moves':['m1','m2'],'conditions':ctx,'sourceVersions':vers}}
top50={'payloadSchemaVersion':1,'mode':'top50','input':{'format':'doubles','rankingSnapshotId':'snap1',
  'attacker':build,'moves':['m1'],'conditions':ctx,'defenderOverrides':{'snap1:r1':build},'sourceVersions':vers}}

passed=0
def check(name,value,valid):
 global passed
 errors=list(validator.iter_errors(value));actual=len(errors)==0
 assert actual==valid,(name,[e.message for e in errors[:4]])
 print(('PASS' if actual==valid else 'FAIL'),name)
 passed+=1

check('normal valid',normal,True)
check('top50 valid',top50,True)
t=deepcopy(normal);t['schemaVersion']='1';check('old top-level schemaVersion rejected',t,False)
t=deepcopy(normal);t['input']['conditions']['flags']=['rain'];check('untyped flags rejected',t,False)
t=deepcopy(normal);t['input']['attacker']['validity']={'kind':'valid'};check('editor-only field rejected',t,False)
t=deepcopy(normal);t['input']['attacker']['statPoints']['attack']=33;check('points greater than 32 rejected',t,False)
t=deepcopy(normal);t['input']['conditions']['supplementary']=[{'kind':'customMultiplier','value':3}];check('arbitrary effect rejected',t,False)
t=deepcopy(normal);t['input']['moves']=[];check('empty move list rejected',t,False)
t=deepcopy(normal);t['input']['moves']=['m']*5;check('more than 4 moves rejected',t,False)
t=deepcopy(top50);del t['input']['rankingSnapshotId'];check('top50 without snapshot rejected',t,False)
t=deepcopy(top50);t['mode']='normal';check('normal mode but top50 payload rejected',t,False)
t=deepcopy(normal);del t['input']['attacker']['status'];check('dropping status rejected',t,False)
# Validate share creation exclusivity and strictness
share_root={'$schema':'https://json-schema.org/draft/2020-12/schema','components':{'schemas':doc['components']['schemas']},'$ref':'#/components/schemas/CreateShareRequest'}
shareval=Draft202012Validator(share_root)
for name, data, expected in [
 ('share snapshot',{'snapshot':normal},True),
 ('share from saved',{'savedCalculationId':'00000000-0000-0000-0000-000000000001'},True),
 ('share both',{'snapshot':normal,'savedCalculationId':'00000000-0000-0000-0000-000000000001'},False),
 ('share neither',{},False),
]:
 assert (not list(shareval.iter_errors(data)))==expected,name
 print('PASS',name);passed+=1
print('PASSED:',passed,'schema cases; TS ref still requires tsc and runtime cross-field validation')
