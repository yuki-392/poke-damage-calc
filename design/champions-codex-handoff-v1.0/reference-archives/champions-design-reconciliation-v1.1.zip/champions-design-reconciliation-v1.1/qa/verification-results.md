# 設計契約の整合性検証結果（2026-10-23）

**対象**: `contracts/shared-contract.reference.ts`, `contracts/openapi-v1.1.yaml`, `qa/validate_design_contract.py`

- TypeScript：`tsc --noEmit --strict --skipLibCheck --target ES2022 --module ESNext` で型チェック通過。
- OpenAPI：PyYAMLでロード可能、OpenAPI 3.1.0、26 schemas、ローカル`$ref`69件がすべて解決。
- JSON Schema 2020-12：**16件**正常ケース/不正ケースの判定が期待どおり。
- 正常: `normal`保存、`top50`保存、スナップショット共有、保存IDから共有。
- 拒否: 旧`schemaVersion`、型なし`flags`、UI一時`validity`、ポイント33、勝手な倍率effect、技0件/5件、snapshot未指定、modeとinputの不一致、状態異常欠落、share両方指定/両方未指定。

**未検査・保留**: statPoints合計66制限、合法性格ベクトル、フォーム/特性/技のマスター照合、実データの版整合、SUPABASE RLS・本物のAPI、認証Cookieの往復、Cron実行と原子DB公開。これらはTSコンパイルやJSON Schemaのテスト成功では保証されない。
