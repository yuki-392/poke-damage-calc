# 旧資料の記述差し替え表 v1.2

この表は**旧ファイルへの適用が必要な改訂箇所**を列挙する。今回の新正本が優先されるため、下記旧ファイルはCodexのコード生成に直接使わせない。最終統合ZIP作成時には旧文書をarchiveに移動するか、以下の新契約を反映した統合版を作る。

| 旧資料 | 旧記述 | 新正本 |
|---|---|---|
| `architecture_v1_docs/architecture-v1.0.md` | 9:30 JST日次 / 00:30 UTC / 1日1回 | `update-schedule-v1.3.md`：`0 * * * *`。毎時確認・成功日に停止 |
| `architecture_v1_1_docs/architecture-decisions-v1.1.md` ADR-005, 今後の承認ゲート | 固定9:30、更新の自動再試行なし | 新契約の毎時実行 + 時間待機 + DB原子的公開 |
| `architecture_v1_1_docs/tech-stack-comparison-v1.1.md` 更新章、比較表、PoC、図 | 9:30起動を前提としたコスト・構成比較 | Supabase Cron 1時間ごと、成功後外部HTTPなしで再評価 |
| `champions-api-integration-design-v1.0/docs/ingestion-and-provenance-v1.0.md` | `30 0 * * *`, 日次1回、試行スキップなし | `update-schedule-v1.3.md`。
| `champions-api-integration-design-v1.0/docs/decisions-and-open-issues-v1.0.md` ADR-API-10 | 「09:30、同日1回、自動再試行なし」 | 「毎時Cron。成功後同日停止。未成功時は次の時間に再確認」 |
| `champions-api-integration-design-v1.0/docs/api-and-dataflow-design-v1.0.md` | Cron 00:30 UTC | Cron `0 * * * *` |
| `champions-frontend-design-v1.0/docs/frontend-state-design-v1.0.md` 5.4 | 「9:30更新でバックグラウンド差替えない」 | 「新publicationの検知後も自動で差替えない」 |
| `champions-frontend-design-v1.0/contracts/frontend-state.reference.ts` | `schemaVersion:string`, `sourceVersions.schemaVersion`, 保存の`BattleContextDraft` | `shared-contract.reference.ts`。保存DTO正本を一つに統合 |
| `champions-api-integration-design-v1.0/contracts/api-contract.reference.ts` | `ValidatedBuild`の status/isMega/origin欠落、flags/extra | `shared-contract.reference.ts`。fields required consistent |
| `champions-api-integration-design-v1.0/contracts/openapi-v1.0.yaml` | `additionalProperties:true`保存条件、曖昧なshare排他、`sb-session`仮Cookie名 | `openapi-v1.1.yaml`。判別可能スキーマ、share `oneOf`、Cookieヘッダーの実仕様に沿う表現 |
| `champions-db-final-design-v1.2` | 毎時/2形式1publicationは現行仕様と整合 | 既存DB論理設計を保持。型/JSON保存境界のみ `canonical-contract-v1.1.md`を優先 |

## 実装開始を許可する意味ではない

- `P0-03` 性格選択、`P0-04` マスター出典、`P0-05` TOP50ゲーム内照合、`P0-06` 計算ゴールデンケース、`P0-07` 共有寿命は未解決。
- `P1-03` メガフォームと`isMega`の二重表現も未解決。
- 旧資料を削除してしまうと決定履歴が消えるため、この時点では消さず**優先順位を明示した上で保存**する。
