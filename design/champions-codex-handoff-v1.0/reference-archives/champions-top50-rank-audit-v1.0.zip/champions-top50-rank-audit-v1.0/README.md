# P0-05: TOP50順位正確性の検証・公開判定 v1.0

- 対象: Pokémon Champions、シーズンM-7／レギュレーションM-C、Singles/Doubles。
- 基準日: 2026-10-23 JST。
- 成果物: **設計レビュー・公開判定規則**。アプリやランキングの実装、実機100枠照合は未実施。
- 結論: 供給元のJSONの構文・順位連番は確認可能だが、**採用候補と同じ日時・レギュレーションのゲーム内画面TOP50との直接全件照合は未達**。『ゲーム内順位と検証済み』とは扱わない。

## ファイル

- `docs/P0-05-ranking-audit-v1.0.md`: 現物データと異なる情報源の比較・根拠。
- `docs/ranking-release-gates-v1.0.md`: Codex実装時に満たすべき検証・公開判断。
- `docs/capture-and-reconciliation-protocol-v1.0.md`: 実機スクリーンショット／目視データとAPIの照合プロトコル。
- `docs/ranking-architecture-delta-v1.0.md`: API・DB・UIへの差分指示。
- `evidence/observed-source-metadata-v1.0.json`: 取得日時とGit blob SHA、比較集計（100件全データは同梱しない）。
- `evidence/sampled-rank-disagreements-v1.0.csv`: サンプル順位の差異（※同時点比較ではない）。
- `contracts/in-game-rank-audit-template.csv`: 実機TOP50を記録する100行の空テンプレート。

## 外部データの取扱い

第三者データの全レコードの再配布は行わず、検証結果・参照URL・SHA・少数の比較例のみ保存する。MunchStats等から自動大量取得しない。提供元の出典表示・合理的キャッシュ・非ミラーリングの要件を順守する。
