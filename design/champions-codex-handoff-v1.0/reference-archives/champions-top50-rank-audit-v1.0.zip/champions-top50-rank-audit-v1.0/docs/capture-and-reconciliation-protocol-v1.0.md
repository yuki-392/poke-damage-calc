# 実機TOP50比較手順 v1.0

## 目的

ゲーム内Battle Dataの**順位**を正とし、公開APIから得たTOP50の順番が一致するか検査する。技の採用率、代表型の正確性検証は別作業。

## 証拠採取

1. ゲームのランクバトル→Battle Dataを開き、シングルとダブルそれぞれの表示形式・シーズン・レギュレーションを確認。メニューの画面キャプチャ/記録を残す。
2. 同一日・可能な限り同時刻に、1〜50位の全ポケモン（フォルムを含む）をゲーム画面から転記。名称のみではなくスプライトや内部の形態を照合。`contracts/in-game-rank-audit-template.csv`を使用。
3. ソースフィードの`generatedAt`とは別に、ゲーム内画面を実際に観測した日時をUTCで記録する。外部側にゲーム画面取得時刻がない場合、比較は `comparability=unknown` とする。
4. 同じ観測基準のソースフィードを取得。Git blob SHAまたはETag、ソースURL、取得日時、`season`/`regulation`が確認できる証拠のURLを記録。
5. 両側を `(format, seasonId, regulationId, canonicalPokemonFormId)` で照合。表示名やNational Dex IDのみで結合しない。
6. ランク1〜50の全件を位置ごとに比較。差分は`wrong_rank`, `missing_in_source`, `missing_in_game`, `form_mismatch`, `source_date_mismatch`, `unknown`に分類。
7. 不一致が出た場合、画面／フィード更新時刻のずれを点検し、必要なら近い時点でもう一度撮り直す。比較不能な場合は「不一致」ではなく「結論保留」とする。
8. 監査者、取得日時、証跡の保存先、判定者、判定結果をレビュー台帳へ記録する。権利面で画面画像を一般公開しない。

## 合格条件

- SinglesとDoublesのそれぞれ先頭50件に対応する**同一フォルム・同一順位**が100%。
- 同一シーズン／レギュレーションに加え、データ比較が有効な観測時刻であることを証明できる。
- ランク検証から代表型の実測性を推論しない。

## 取り扱えない状況

ゲーム実機、同時点の信頼できるゲーム内キャプチャ、またはフォーム特定に必要な情報が不足している場合は `P0-05 unresolved`。手動入力可能な検証データの受け取りを条件に未解決のまま残す。外部サイトのランキング順位が類似しているだけで完了扱いにしない。

## 参考キャプチャソース

MunchStatsはゲームの画面直接取得を説明しているが、今回確認できたDoublesページのゲーム内取得日は2026-10-06。https://www.munchstats.com/about/  https://www.munchstats.com/champions/doubles/Garchomp

Pokestはゲーム内ランキング集計と記載、トップページの日付は2026-10-12。https://pokest.com/en
