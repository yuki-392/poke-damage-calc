# P0-05 API・DB・UI・更新運用への差分契約

**優先関係:** 要件v0.3 → UI v0.5 → 更新方針v1.2（毎時） → U-06（共有除外） → 本P0-05検証条件。以前の9:30固定・共有90日歴史保存は無効。

## API/DTO

- `RankingResponse` の形式別に `source.providerId`, `source.url`, `source.rankDefinition`, `source.seasonId`, `source.regulationId`, `source.generatedAt`, `source.observedAt?`, `source.fetchedAt`, `source.verifiedAt?`, `rankEvidence`, `comparability`, `publishedGenerationId`を明示。
- `rankDefinition=ingame_ordinal | showdown_usage_order | unknown` を含め、割合は`usageRate:number|null`にして未知値に0を代入しない。
- 推定代表型は `build.kind=estimated` と根拠フィールド。`observed` の扱いは根拠がある場合だけ。
- 時刻はUTC ISO8601。生成・収集・当方取得の3時刻を混同しない。時刻がなければnull。
- 保存する個人の計算条件は`catalogVersion`, `rulesetVersion`, TOP50参照時は`publishedGenerationId`を持ち、**共有URL用の世代履歴は持たない**。ユーザーの保存データ再表示時の古いランキング取扱いは別の保存ポリシーに従う。

## DB

- `ranking_generations`に両形式のセット、出典メタデータ、検査ゲート結果、監査証跡を関連づける。
- `ranking_snapshots`/`ranking_entries`は、公開世代に所属する形式・順位・カタログのID整合性をDB制約／トランザクションで担保。
- `ranking_validation_runs` 相当の監査イベントに差異、観測日時、キャプチャ元、担当者、ファイルのSHA等を保存。第三者サイトの著作物の無断再配布を避け、証跡は内部管理。
- 最新更新ジョブは毎時軽量確認。当日成功確認後は外部リクエスト停止。新データが公開後30分以上経過してからG0/G1/G3/G4を検査する。G2の実機監査は定期／異常検知時の別ジョブで、未監査の新世代を「当日実機照合済み」としない。
- 両形式をアトミック公開し、片方のみ更新禁止。変化なし・部分失敗では以前の正常世代を保持。

## UI

- データ根拠として「ゲーム内順位を検証した最終日」「ランキング情報の提供元」「提供元の観測日（分かる場合）」を区別。
- `rankEvidence != game_screen_compared` の場合、**「ゲーム内TOP50検証済み」と書かない**。内部検証プレビューなら「暫定TOP50（ゲーム内順位未照合）」を明示。
- Showdownなど別種の統計しか取得できない場合、ユーザー要求のゲーム内TOP50へ自動すり替えず、TOP50機能を公開保留にする。
- TOP50の編集、200計算、通常計算への遷移は既存UI v0.5の仕様どおり。ランキングの出典確認は計算機本体のログイン要件と無関係。
- 出典表示: `Battle data provided by Pokémon Champions Battle Data` と提供元リンクをTOP50画面等に掲示（必要な場合）。

## 最終ハンドオフ

CodexにP0-05を「検証済み」と伝えてはならない。実装できるのは比較ツール・品質ゲート・監査UI・データ正規化であり、**実機照合の証拠自体は人間の検証または許諾ある一次データアクセスを要する**。
