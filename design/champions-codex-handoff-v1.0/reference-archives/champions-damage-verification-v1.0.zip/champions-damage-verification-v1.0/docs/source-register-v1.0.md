# 参照情報と信頼性レジストリ

調査時点：2026-10-23 JST。リンク先は更新されうるため、Codexでの検証時には取得日時、コミットSHA、外部ルール版を固定する。

| ID | 出典 | 本設計で使った情報 | 注意 |
|---|---|---|---|
| SRC-01 | https://champions.pokewiki.net/ダメージ計算式 | Lv50基礎算術、16乱数、補正値、補正順序、壁、急所、ダブル | **L2**。旧世代のテラ/Z技/ダイマックス記述が混在、現行Championsへの適用範囲要確認 |
| SRC-02 | https://pkmn-cp-dataportal.com/battle/damage/damage-order/ | Lv50基礎式、乱数16通り、段階ごとの丸め | **L2**。SRC-01と補正のまとめ方・説明単位が異なる。一次仕様ではない |
| SRC-03 | https://smart-calculators.net/ja-JP/tools/pokemon-champions-damage-calculator | 15通り→16通りという非公式の更新説明、独立計算機の実装方針 | **L2**。日付・差分説明は公式パッチや実機照合なしに確定しない |
| SRC-04 | https://github.com/smogon/damage-calc/blob/master/calc/src/mechanics/champions.ts | Champions専用計算経路の存在、参照実装の候補 | **L2**。上流最新版と本番採用する版は異なりうる。コミット固定が必要 |
| SRC-05 | https://github.com/smogon/damage-calc/blob/master/LICENSE | ソフトウェアのMITライセンス | コード再利用時はライセンスを同梱。マスター・画像等は別規約の場合あり |
| SRC-06 | https://github.com/joshuamatalon/champions-lab | 固定版のShowdown/Smogonでゲーム挙動との照合をうたう例 | 第三者の主張であり、当アプリのL3証跡ではない |
| SRC-07 | `champions-design-damage-v1.2/docs/damage-engine-detailed-design-v1.2.md` | 既存エンジンの入出力・効果フェーズ契約 | 独立ソースではなく内部の設計。ゲーム保証ではない |
| SRC-08 | `champions-damage-engine-v1.1/docs/implementation-v1.1.md` | 試作の実装範囲と23件の開発テスト | **L0/L1**。ゲーム照合済みという意味ではない |
| SRC-09 | `champions-design-decisions-v1.7/docs/U-06-remove-sharing-v1.7.md` | 共有URL機能の削除 | ユーザーの最新決定として旧設計に優先 |

## 出典の信頼性

- **L3**：ゲームの現在有効なバージョンで、再現可能な入力とダメージ観測、観測日時、証拠と第三者レビューが残る。ゲーム画面を1回見ただけでは確率分布の全体は確定しない。
- **L2**：Wiki、公開されている第三者の計算式資料、別の計算機、MIT実装。仕様候補の発見と差分検出に使えるが、ゲームとの完全一致とは区別する。
- **L1**：標準数学・整数計算。ゲームの効果条件は導出できない。
- **L0**：UI・API契約、入力境界、状態遷移の静的検証。

このファイルは、参照元の文章・コードを再配布するものではない。
