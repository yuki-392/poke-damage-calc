# Pokémon Champions ダメージ計算・正確性検証設計 v1.0

設計段階の P0-06 監査結果と、Codexが実装・検証するときの受け入れ基準。**このパックに新規エンジン実装は含めない。ゲーム本体との全ケース照合も未実施。**

- `docs/P0-06-mechanics-audit-v1.0.md` — 現状の事実確認、衝突する資料、誤実装を防ぐ設計上の変更。
- `docs/test-and-evidence-plan-v1.0.md` — 最低限の計算・効果・TOP50検証マトリクスと証跡取得手順。
- `docs/codex-acceptance-gates-v1.0.md` — Codexへの開発引き継ぎ条件と公開ゲート。
- `docs/source-register-v1.0.md` — 文献、確認日、根拠レベル、ライセンス上の注意。
- `contracts/golden-case.schema.json` — 実測フィクスチャを構造化するJSON Schema（設計補助）。
- `contracts/verification-cases.csv` — 各テストについて確認先と合格条件を記録できるマトリクス。
- `contracts/observations-template.csv` — **実機で取得した値だけを記入する**ログひな形（初期状態は空）。

先行資料：`champions-design-damage-v1.2`（効果設計）、`champions-damage-engine-v1.1`（精度保証前のプロトタイプ）、`champions-master-data-design-v1.0`、`champions-top50-rank-audit-v1.0`、`champions-design-decisions-v1.7`（共有URLの初期リリース除外）。

判定：**P0-06 は「検証設計済み、実機の数値一致は未解消」。** 設計作業を継続・Codex実装へ引き継いでよいが、公開時に正確性が確認されたと主張する条件ではない。
