# Pokémon Champions ダメージ計算アプリ — API・データ連携詳細設計 v1.0

作成日: 2026-10-23 / フェーズ: **設計のみ・実装なし**

## 設計資料の参照順

1. `docs/api-and-dataflow-design-v1.0.md` — システム境界・API一覧・データフロー・IDとバージョン
2. `docs/ingestion-and-provenance-v1.0.md` — TOP50外部統計の取得・9:30更新・検証・公開
3. `docs/auth-save-share-design-v1.0.md` — 認証・保存・同期・共有・認可
4. `docs/db-integration-amendments-v1.0.md` — DB詳細設計を確定させるための変更案
5. `docs/error-and-acceptance-tests-v1.0.md` — エラー仕様・受け入れテスト
6. `docs/decisions-and-open-issues-v1.0.md` — 決定事項、保留事項、Codexへの引き継ぎ
7. `contracts/api-contract.reference.ts` — **参考型定義のみ。アプリ実装ではない**
8. `contracts/openapi-v1.0.yaml` — 外部公開APIではなく、**本アプリ内部のNext.js BFF**のHTTP契約ドラフト

## この設計の前提

- UI v0.5、要件 v0.3、フロント状態管理 v1.0、計算エンジン詳細設計 v1.2、DB設計 v1.0＋補足 v1.1を参照。
- NEXT.js Route Handlers をWebアプリ内部のBFFとして使用。ブラウザが外部統計プロバイダーへ直接アクセスしない。
- ダメージ計算はブラウザ内で共通TypeScript計算エンジンを使用。HTTP計算APIは初期実装で作らない。
- TOP50の元データのメイン候補はPokémon Champions Battle Data（公開サイトおよびGitHubに存在する集約JSON）。ただし、実データの構造確認とゲーム内順位の正確性検証は別。**本番ランキングの公開許可は未確定**。
- 明示保存・共有は合法な入力のみ受け付け、詳細内の一時的な技・戦闘条件は明示転写しない限り保存しない。

## 重要な保留事項（本番前のブロッカー）

1. メイン候補のTOP50がゲーム内ランキングと一致することの確認と、提供元の利用条件に沿うキャッシュ・共有保持期間。
2. ポケモン・技・特性・持ち物のマスターデータの一次出典と版の決定。
3. 共有リンクの有効期限・匿名作成を認めるかの最終UX判断（本設計の推奨案は**作成はログイン必須、閲覧は匿名可**）。
4. 保存・共有に含めるランキング由来データの最小化と、長期再現性/再配布制限の両立。
5. 既存DBスキーマに対するpublication単位の一貫性、IDおよび認可の変更案を次工程で確定。

参照サイト:
- https://championsbattledata.com/api_guide
- https://championsbattledata.com/api-rules/
- https://github.com/Gheist23/pokemonbattledata
- https://supabase.com/docs/guides/cron
- https://supabase.com/docs/guides/functions/schedule-functions
- https://supabase.com/docs/guides/database/postgres/row-level-security
- https://supabase.com/docs/guides/auth/server-side
- https://nextjs.org/docs/app/api-reference/file-conventions/route
