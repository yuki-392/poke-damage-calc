# DB設計との接続・最終統合変更案 v1.0

## 1. 対象と責任分界

既存の`202610230001_initial_schema.sql` + `202610230002_rank_verification.sql`に対する**設計上の差分**。本書はmigrationコードではなく、次の「DB最終統合」で確定する仕様案。SQL適用/動作検証はまだしていない。

## 2. 必須の整合性変更

| ID | 既存設計とのギャップ | 変更案 | 優先度 |
|---|---|---|---|
| DB-01 | `active_rankings`が形式ごとに2行で、独立したAPIの読取り時に世代が混在し得る | `ranking_publications(id,singles_snapshot_id,doubles_snapshot_id,published_at)`と**単一**の`active_publication` pointer追加。1トランザクションで切替 | 必須 |
| DB-02 | `rank_verification`がsnapshotにのみあり、ソースごとの継続承認を表現できない | `source_approvals(source_id,format,regulation_id,definition_fingerprint,approved_at,revoked_at,approval_evidence)`追加 | 必須 |
| DB-03 | `ingest_runs.outcome`に承認待ちがない | `awaiting_verification`を追加。失敗・変化なし・公開済みを区別 | 必須 |
| DB-04 | JSON versionが保存ではinteger、frontend参考型ではstring | 外部payloadの`payloadSchemaVersion:number`を正とし、フロント内部の`schemaVersion`を統合/明示変換 | 必須 |
| DB-05 | `ranking_entries`にUUID行IDがないがUIは`rankingEntryId`を必要とする | DB PKは複合のまま。APIで`${snapshotId}:r${rank}`を生成。`defenderOverrides`はこのキー | 必須 |
| DB-06 | 保存POST/共有POSTが二重送信された時の扱い未定義 | `api_idempotency_keys`（owner,route,key,request_hash,serialized_result_encrypted,expires_at）を追加、期限付きで管理 | 推奨 |
| DB-07 | 共有・保存入力の版整合性がJSONBのみに依存 | DB列に`payload_schema_version`/`revision`保持。API Zod型検証とDB checkの二重化、`source_versions`の検証 | 必須 |
| DB-08 | Provider status enumとUIの`measured/estimated`の名称が違う | DB `observed` ↔ API `measured`をAdapterで固定、`incomplete`は未計算警告 | 必須 |
| DB-09 | 利用条件に対するsnapshot retention/共有再現が未確定 | `retention_until`,`license_policy_ref`などの記録、削除の影響確認。ただし期限値は規約確認後に決定 | 要確定 |
| DB-10 | 共有token hashだけでは冪等作成時に元tokenを再現できない | share作成時の**短期暗号化レスポンス保管**、期限内のみ同レスポンス、期限後の同keyは409とする案 | 要検証 |

## 3. 発行世代の一貫性

```mermaid
sequenceDiagram
 participant E as Ingest Edge Function
 participant PG as PostgreSQL
 participant UI as API reader
 E->>PG: CREATE staging snapshots(S,D)
 E->>PG: validate both/verify source
 E->>PG: BEGIN publication(S,D) + update active pointer + COMMIT
 UI->>PG: SELECT active publication + 2 snapshot entries (same read snapshot)
 PG-->>UI: pub-2026... のS 50件 / D 50件
```

**必須DB関数（機能契約）**:
- `publish_rankings(singles_snapshot_id,doubles_snapshot_id, ingest_run_id)` — 管理者限定、各50件・同じ規定の検証・承認をチェック、publicationとactive pointerを原子的に更新。
- `read_active_rankings()` — 現在のpublication IDに紐づくシングル/ダブル50件を**同一MVCC snapshot**で読み取り、DTO生成用に返す。関数権限を限定し、汎用元統計JSONを返さない。

`active_rankings` 2行を残す場合は互換用として参照専用にし、公開APIの真実のソースにはしない。既存`guard_active_ranking_source()`と整合するように統合/移行すること。

## 4. 保護・権限

- `saved_calculations`: 自分の行に`SELECT/INSERT/UPDATE/DELETE`、新ownerIdは`auth.uid()`と一致。権限GRANTも限定。
- `shared_calculations`: クライアントからの任意SELECTは禁止。サーバーの限定共有ルートでtoken hash照合、期限・失効確認。
- `ranking_snapshots`, `usage_options`, `ingest_runs`: 一般ユーザーの直接書き込み禁止。読み取りも用途に応じた集約DTOのみ。
- `source_approvals`, `ranking_publications`, active pointerは管理処理のみ。
- `service_role`はブラウザやユーザー操作の任意BFF保存には使用しない。必要な管理経路には限定された資格情報を使用。
- RLSおよび**GRANT**を実DBで検証。初期migrationが持つ`public`スキーマのデフォルトgrantを監査。

## 5. トランザクションと同期

### 保存更新

`UPDATE saved_calculations SET ... WHERE id = :id AND owner_id=:actor AND revision=:expected`。0件更新なら本人の存在可否確認に応じて404/409。既存revision triggerが1つだけ増加させるよう、手動増分との二重適用を禁止。

### Idempotency

- DBユニークキー `(owner_id, operation, idempotency_key)`。
- 複製リクエストは同一body hashのみ再使用。異なるbody hashは409。
- 保存結果はID等のみ。共有作成のtokenを繰り返し返す場合は短期に**暗号化して保管**（平文tokenを長期保管しない）。
- 定義する保存期間はセキュリティ監査後に確定。

### TOP50の入替

- 新旧snapshotをユーザーセッション内で勝手に混在させない。
- `rankingEntryId`は`${snapshotId}:r${rank}`（決定的文字列）で一意。新snapshotでは別キーになるので旧overrideを自動適用しない。

## 6. データモデル例

```text
ranking_publications
  id UUID (PK)
  singles_snapshot_id UUID (FK ranking_snapshots)
  doubles_snapshot_id UUID (FK ranking_snapshots)
  published_at TIMESTAMPTZ
  ingest_run_id UUID

active_publication
  singleton_id SMALLINT PRIMARY KEY CHECK(singleton_id=1)
  publication_id UUID NOT NULL REFERENCES ranking_publications(id)
  switched_at TIMESTAMPTZ

source_approvals
  source_id TEXT; format TEXT; regulation_id TEXT
  definition_fingerprint TEXT; approved_at TIMESTAMPTZ
  revoked_at TIMESTAMPTZ NULL; approval_evidence TEXT
```

DDL（trigger、transaction isolation、FK constraintなど）は次回DB最終工程で作る。

## 7. 本番導入のゲート

1. 既存SQL 001→002→最終migrationの順で適用し、rollbackも検証。
2. 未承認source/snapshotが`active_publication`にならないこと。
3. 片形式のみ50件または未承認の時、古いpublicationが残ること。
4. user AとBのRLS・GRANTによる分離を自動テスト。
5. 共有失効/期限/保存revision競合がDBとAPIで一致。
6. カタログ出典、データ保持期間、外部統計の永続再利用可能性が確認されること。
