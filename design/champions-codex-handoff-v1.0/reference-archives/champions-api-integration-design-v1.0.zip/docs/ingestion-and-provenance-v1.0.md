# TOP50取得・更新・出典管理 詳細設計 v1.0

## 1. 取得元と技術検証の到達点

- **第一候補:** Pokémon Champions Battle Data API / サイトの集約データ。
- 参照リポジトリ: https://github.com/Gheist23/pokemonbattledata
- 以前の検証では`data/builder/meta-singles.json`・`meta-doubles.json`を読み、両方に `pokemon[].position`、`set`、`natures`、`spreads`、`abilities`、`items` があることを確認した。
- `set`は**同時採用率を確認した一つの完全構成ではない**。上位項目を組み合わせたため、`buildOrigin='estimated'`とする。
- `/api_guide`のAPIはポケモン単体・統計行取得に対応。集約JSONの永続URLを公式の安定API契約とみなす前に、サイト本番URLと利用条件を別途照合する。
- 外部ランキングとゲーム内TOP50の一致は**未検証**。読み取れたJSONの順位をそのまま「公式/ゲーム内確定順位」と表示しない。

## 2. Adapterの契約

インターフェース（設計上）:

```ts
interface RankingProviderAdapter {
  readonly sourceId: string;
  getDailyRanking(format: 'singles'|'doubles'): Promise<ProviderPayload>;
  normalize(payload: ProviderPayload, format: BattleFormat): NormalizedRankingDraft;
}
```

| 区分 | Providerのフィールド | 正規化後 | 注意 |
|---|---|---|---|
| 形式 | `format` (`Singles`/`Doubles`) | `singles`/`doubles` | クエリ指定の形式と一致必須 |
| データ生成日時 | `generatedAt` | `sourceGeneratedAt` | 「取得日時」と別 |
| 順位 | `pokemon[].position` | `rank` | 1〜50、重複・欠番を禁止 |
| ポケモン識別 | `name`,`species`,`form` | `pokemonFormId` | 辞書による一意照合必須 |
| 使用率 | 集約JSONに未提供 | `usageRate:null` | 推定・0代入しない |
| 能力ポイント | `set.bonuses[0..5]` | HP/Atk/Def/SpA/SpD/Spe | 各0..32、合計<=66 |
| 性格 | `set.nature` | `natureId` + 倍率vector | 名称からフル補正を復元。UIは参照能力の倍率だけ表示 |
| 特性 | `set.ability` | `abilityId` | Formの合法候補照合 |
| 持ち物 | `set.item` | `itemId`または未解決 | 未解決なら`incomplete`扱い |
| 技 | `set.moves` | 正規化済みmove IDs | 習得技と照合。未習得なら警告（黙って差替えない） |
| 採用率別統計 | `natures`,`spreads`,`items`,`abilities`,`moves` | `usage_options` | カテゴリ別統計。`complete_build`と偽装しない |

対象は最初の50匹のみ。提供元レコード全体をキャッシュし直して外部向けに再配布しない。読み込み容量を抑えるため、必要ならサーバーのみで圧縮キャッシュ/ETagを使用する。

**ID変換**: `source_pokemon_ids(source_id, external_id) -> pokemon_forms.id`。`external_id`はShowdown名＋フォーム固有の正規化キーを採用し、全国図鑑番号だけで判定しない。未照合が1件でもあれば、**その形式の今回更新を不採用**。文字列の近似一致で自動公開しない。

## 3. 更新実行と冪等性

- Cron: **Asia/Tokyo毎日09:30** = UTC 00:30、式 `30 0 * * *`。
- Supabase Cron → 認証済みEdge Function `ingest-top50`。呼出認証情報はSupabase Vaultなどサーバー管理に保持する。`service_role`/secretをブラウザへ公開しない。
- `ingest_runs.scheduled_for_jst` は当日の実行試行を1つに限定。DBの一意制約＋排他ロック/compare-and-setで二重処理を防ぐ。
- **自動再試行なし**。ネットワーク内部のHTTP Retryも仕様上の「一度」から外れるため、ポリシーを決めるまでは無効。手動運用リカバリは別の監査可能な管理操作として扱う。
- Cron起動は9:30指定であり、秒単位の終了保証ではない。ログには`scheduled_for_jst`, `attempted_at`, `completed_at`を区別。
- 前回source `content_hash`と一致するときは`unchanged`。**取得確認日時を更新する**ことと、**元データの生成日時を書き換える**ことを混同しない。

## 4. 取込状態機械

```mermaid
stateDiagram-v2
  [*] --> initiated
  initiated --> fetched : 両形式の取得成功
  initiated --> failed : 取得失敗
  fetched --> normalized : スキーマ/ID/代表型を正規化
  fetched --> failed : 不正JSON等
  normalized --> staged : DBへ未公開保存
  normalized --> failed : 不正順位/配分/フォーム
  staged --> unchanged : 両形式ともcontent_hash同値
  staged --> awaiting_verification : 出典未承認または順位未検証
  staged --> ready_to_publish : 出典承認済み&更新検証成功
  ready_to_publish --> published : 2形式同一世代を原子的公開
  ready_to_publish --> failed : DB公開失敗
  published --> [*]
  unchanged --> [*]
  awaiting_verification --> [*]
  failed --> [*]
```

`awaiting_verification`は初期DB設計の`ingest_runs.outcome`にないため、次工程でenum/checkを拡張（`docs/db-integration-amendments-v1.0.md`参照）。**元APIが返したJSONの構造に異常がないだけで公開承認しない**。

## 5. バリデーション・公開条件

### 5.1 構造検証（毎日の自動検証）

- 各形式の元JSONが妥当なオブジェクトで、形式識別と生成日時が妥当。
- 1〜50位が**ちょうど50件**、重複/欠番/フォームID重複なし。
- 50フォームすべてを`pokemon_forms`に一意マッピングできる。
- 能力ポイントは6個の整数で各0〜32、合計<=66。
- 性格補正に合法なベクトルが存在すること。特性と持ち物のIDをマスターへ照合できること。
- `usageRate`は未提供ならNULL。別提供元の割合を無断で併合しない。
- `sourceGeneratedAt`が未来の異常時刻や旧レギュレーションへの明らかな巻き戻りなら検証停止。
- 提供元・レギュレーション・出典版・元コンテンツSHA256を記録する。
- 統計値に欠損がある場合は`estimated/incomplete`に分類。**合法な代表型を生成できない防御側**は公開阻止か、該当結果を「未計算」とするかを本番前に決定する（後者の場合も50匹を消して補充しない）。

### 5.2 出典の承認（必要時に人が確認）

- 最初の提供元採用時とシーズン/集計定義が変わった時に、ゲーム内順位との対照、利用規約、順位の由来を確認する。
- sourceとformatごとに`source_approval_status`を持たせる。片方のみ承認済みなら両形式を`active`に切り替えない。
- 既に承認済みの同一出典・同一集計定義・同一レギュレーションでは、毎日の再取得を構造検証のみで自動公開できる方針を採用（承認失効時は停止）。
- 現在の公開JSONは本調査ではゲーム内実測との順位対照が未実施。**初回のproduction公開前には必須**。

### 5.3 公開の原子性

- 新しい`ranking_snapshots`・50件の`ranking_entries`・対応する`representative_builds`を**両形式**stagingへ保存。
- DBトランザクション内で`ranking_publication`の単一active pointerを更新し、同一publication IDに紐づく2形式のSnapshotを確定する。
- 途中で失敗したらrollbackし、旧publicationを維持。クライアントは更新中でも旧世代を読める。
- 既存`active_rankings`の2行を更新する方式だけでは、複数SQL問合せ時の世代不一致を防ぎきれない。**1世代IDから同じDB snapshotで2形式の情報を取得するRPC/SQL関数**が必要。
- レギュレーションの違うシングル・ダブルを一つに混ぜない。もし提供元都合で異なる場合は検証して公開可否を保留する。

## 6. 元データの保存・ライセンス

- 出典: https://championsbattledata.com/api-rules/
- 採用候補APIは公開アプリでの利用を認め、出典表示と合理的なキャッシュを要求し、データサービスとしての再配布や永久ミラーを禁止。
- 本アプリは **50件分の計算を提供するための最小限の加工データ**に限定する。統計全件・過去全量を第三者が機械的に取得できるAPIは提供しない。
- キャッシュ保存期間/削除期間は**規約とユーザー共有の再現性要件を両立するよう別途最終決定**する。現時点で「無期限保持してよい」と確定しない。
- 出典リンク・非公式表記をアプリのTOP50画面/関連情報に明示する。

## 7. 監視・障害の扱い

| 状況 | ジョブ結果 | UI表示/影響 |
|---|---|---|
| 取得成功・新データ | `published` | UIを自動で差替えない。新データありと通知 |
| 取得成功・前回と同じ | `unchanged` | 前回Snapshotを使用し取得確認時刻のみ更新 |
| ネットワーク失敗 | `failed` | 旧Snapshot維持。通常計算は継続 |
| 片方の形式だけ失敗 | `failed` | 両方とも旧publication維持 |
| フォルム未解決 | `failed` | 公開中データ維持、運用者へアラート |
| 出典未承認 | `awaiting_verification` | 内部staging、未承認の「ゲーム内TOP50」を本番に出さない |
| 提供元取得時刻が古い | 許容範囲により`unchanged`/要調査 | `sourceGeneratedAt`をそのままUI表示 |

運用者は`ingest_runs`とCron実行ログから失敗理由と入力データのSHA、対象formatを追跡できる。ユーザーには技術的なstack traceを出さない。

## 8. 検証ケース

- 50件未満、順位欠番、重複フォーム、合計67ポイント、未知フォーム/特性/持ち物、未来timestampを全て取り込めないこと。
- 同じ日に重複起動しても一度しか公開しないこと。
- シングル成功・ダブル失敗時に両方の旧版を保持すること。
- sourceGeneratedAtが同じでも応答の内容hashが変化した場合は更新判定すること。
- 公開pointerが変更される直前/直後のクライアントが2形式で異なる世代を観測しないこと。
- sourceの利用規約・出典リンクをUI上で表示できること。

## 9. 本番前の継続検証

- 候補ソースの最新JSON URLを外部ネットワーク環境から安定して取得できるか（`championsbattledata.com/data/builder/...`のURLは本調査で確実なレスポンスを検証できていない。**確定URLとしてコードに固定しない**）。
- GitHub公開ファイルの取得は検証できたが、GitHubのブランチとリリースAPIを恒久的な本番配信基盤にする条件は別途評価する。
- Pokémon Champions本体のゲーム内TOP50との順位対照をシングル・ダブル両方で実施すること。
