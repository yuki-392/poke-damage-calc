/**
 * API + DATA INTEGRATION CONTRACT v1.0 — DESIGN REFERENCE ONLY.
 * NOT SHIPPING CODE. Harmonize with frontend-state.reference.ts and DB v1.2
 * before implementation. No network calls, runtime validation, or database logic.
 */
export type BattleFormat = 'singles' | 'doubles';
export type DamageEngineStatus = 'ok' | 'nonDamaging' | 'missingContext' | 'unsupported' | 'invalid';
export type StatId = 'hp' | 'attack' | 'defense' | 'spAttack' | 'spDefense' | 'speed';
export type NonHpStat = Exclude<StatId, 'hp'>;
export type NatureFactor = 0.9 | 1 | 1.1;
export type BuildOrigin = 'measured' | 'estimated' | 'incomplete';

/** SourceVersions is separate from payloadSchemaVersion. */
export interface SourceVersions {
  ruleVersion: string;
  masterDataVersion: string;
  effectCatalogVersion: string;
  regulationId: string;
}
export interface ApiMeta { requestId: string; }
export interface ApiSuccess<T> { data: T; meta: ApiMeta; }
export type ApiErrorCode =
  | 'INVALID_REQUEST' | 'AUTH_REQUIRED' | 'FORBIDDEN' | 'NOT_FOUND'
  | 'REVISION_CONFLICT' | 'IDEMPOTENCY_CONFLICT' | 'SNAPSHOT_EXPIRED'
  | 'SHARE_EXPIRED' | 'PAYLOAD_TOO_LARGE' | 'VALIDATION_FAILED'
  | 'VERSION_INCOMPATIBLE' | 'PRECONDITION_REQUIRED' | 'RATE_LIMITED'
  | 'RANKING_NOT_READY' | 'INTERNAL_ERROR';
export interface ApiFailure {
  error: {
    code: ApiErrorCode;
    message: string;
    requestId: string;
    details?: Readonly<Record<string, unknown>>;
  };
}

export type ItemChoice =
  | { kind: 'none' }
  | { kind: 'known'; itemId: string }
  | { kind: 'customText'; text: string };

/** Validated engine input, not editable text drafts. Internal full 6-stat data. */
export interface ValidatedBuild {
  pokemonFormId: string;
  abilityId: string | null;
  item: ItemChoice;
  natureId?: string | null;
  natureFactors: Record<NonHpStat, NatureFactor>;
  statPoints: Record<StatId, number>;
  currentHp: number | null;
  stages: Partial<Record<NonHpStat, number>>;
}
/** Full schema to be integrated with damage-engine's BattleContextDraft. */
export interface BattleContextInput {
  weather: 'none' | 'sun' | 'rain' | 'sand' | 'snow';
  terrain: 'none' | 'electric' | 'grassy' | 'misty' | 'psychic';
  flags: readonly string[];
  extra?: Readonly<Record<string, unknown>>;
}
export interface NormalSavedInput {
  format: BattleFormat;
  attacker: ValidatedBuild;
  defender: ValidatedBuild;
  moves: readonly string[]; // 1..4 and known move IDs
  conditions: BattleContextInput;
  sourceVersions: SourceVersions;
}
export interface Top50SavedInput {
  format: BattleFormat;
  rankingSnapshotId: string;
  attacker: ValidatedBuild;
  moves: readonly string[];
  conditions: BattleContextInput;
  defenderOverrides: Readonly<Record<string, ValidatedBuild>>; // rankingEntryId
  sourceVersions: SourceVersions;
}
export type SavedInputSnapshot =
  | { payloadSchemaVersion: 1; mode: 'normal'; input: NormalSavedInput }
  | { payloadSchemaVersion: 1; mode: 'top50'; input: Top50SavedInput };

export interface Attribution { label: string; url: string; }
export interface RankingEntryDto {
  rankingEntryId: string; // `${snapshotId}:r${rank}`
  rank: number; // 1..50
  pokemonFormId: string;
  usageRate: number | null; // 0..1 when known, null otherwise
  buildOrigin: BuildOrigin;
  representativeBuild: ValidatedBuild | null;
  warnings: readonly string[];
}
export interface RankingDto {
  snapshotId: string;
  format: BattleFormat;
  regulationId: string;
  sourceId: string;
  sourceGeneratedAt: string | null; // UTC ISO 8601
  fetchedAt: string;
  verificationStatus: 'verified_ingame' | 'unverified' | 'external_ladder';
  rankingProvenance: 'ingame_rank' | 'external_ladder_rank' | 'unverified_rank';
  attribution: Attribution;
  entries: readonly RankingEntryDto[]; // exactly 50 for published
}
export interface ActiveRankingsDto {
  publicationId: string;
  publishedAt: string;
  rankings: Readonly<Record<BattleFormat, RankingDto>>;
}
export interface BootstrapDto {
  apiVersion: 'v1';
  payloadSchemaVersion: 1;
  sourceVersions: SourceVersions;
  masterManifestUrl: string;
  activePublicationId: string | null;
  rankingAvailability: 'available' | 'unverified' | 'unavailable';
}
export interface SavedCalculationSummary {
  id: string;
  title: string;
  mode: 'normal' | 'top50';
  format: BattleFormat;
  revision: number;
  updatedAt: string;
  createdAt: string;
}
export interface SavedCalculationDto extends SavedCalculationSummary {
  snapshot: SavedInputSnapshot;
}
export interface Page<T> { items: readonly T[]; nextCursor: string | null; }
export interface UpsertCalculationRequest {
  title: string;
  snapshot: SavedInputSnapshot;
}
export interface CreateShareRequest {
  /** Exactly one must be set. */
  snapshot?: SavedInputSnapshot;
  savedCalculationId?: string;
  expectedRevision?: number;
}
export interface CreateShareResult {
  shareId: string;
  shareUrl: string;
  expiresAt: string | null;
}
export interface SharedCalculationDto {
  snapshot: SavedInputSnapshot;
  expiresAt: string | null;
  /** Optional warning when referenced historical data is not available. */
  warnings: readonly string[];
}

/** Design-time invariants to enforce with Zod + DB constraints, not with TS alone:
 * - 1..4 moveIds, known IDs and version compatibility
 * - 0..32 per stat, total <=66, nature vector valid
 * - no invalidDraft or transient detail conditions in saved/shared payload
 * - published rankings are 50 entries per format in the same publication
 * - share token only passed via opaque URL, never stored verbatim in DB
 */
