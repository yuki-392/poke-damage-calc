# Pokémon Champions ダメージ計算アプリ — 設計横断レビュー v1.0

- レビュー日: 2026-10-23
- 範囲: 要求/要件定義（会話中の確定事項）、確定UI v0.5、技術選定 ADR v1.1、アーキテクチャ v1.0、TOP50更新ポリシー v1.2、API v1.0、フロント状態管理 v1.0、DB統合 v1.2、ダメージエンジン v1.2、参考プロトタイプ
- 方法: **格納済みの各設計資料の文面・TypeScript参考型・OpenAPI・DB論理仕様を相互照合**。本レビューでAPI接続、Supabase実DBテスト、Champions実機対照は実施していない。
- 結論: 全体アーキテクチャは整合するが、**Codex最終一括受け渡しは保留**。文書上の旧契約、DTO不整合、仕様未承認、データ/ゲームルールの検証ゲートが残る。

## 1. 仕様の優先順位（レビューで採用）

1. 会話内の最後のユーザー確定事項：シングル/ダブル、4技×TOP50、UI v0.5の個別修正、1時間ごとの軽量更新・成功後当日停止等
2. 最新の合意文書：画面設計 v0.5、更新ポリシー v1.2、DB統合 v1.2
3. エンジン詳細設計 v1.2、フロント v1.0、API v1.0（旧更新ルールは無効）
4. 技術選定 ADR v1.1。次工程で刷新する古いアーキテクチャ文書 v1.0
5. 実装試作 v1.1とHTMLモックのダミー計算値（**仕様の正本にしない**）

## 2. 整合している重要要件

- 通常計算・TOP50は同じ純粋な計算エンジンを利用、クライアント内で200組を評価
- 物理/特殊で画面の必要能力のみを表示し、裏では6能力を保持
- TOP50詳細の技・戦闘条件はローカル一時状態、個体の型編集は該当entry overrideに反映
- TOP50詳細→通常計算の明示転写で、攻撃・防御型、選択技、ローカル条件、形式を継承
- 実測/推定代表型の区別。項目別採用率の上位を合わせただけでは「実測最多型」にしない
- 版を固定したランキング・保存条件・共有スナップショット、過去ルールへ黙ってマイグレーションしない
- 更新時はシングル・ダブルを同一publicationにまとめ、失敗した場合は前の版を維持
- 共有元のprivateデータを公開せず、RLS/GRANTとサーバーのtoken検証を併用

## 3. 要修正事項一覧

### 必須：Codexへの一括受け渡し前に仕様を確定/一本化（P0）

| ID | 問題・文書根拠 | 影響 | 解決方針 | 状態 |
|---|---|---|---|---|
| P0-01 | **更新仕様が新旧混在**。`architecture_v1_docs/architecture-v1.0.md:14,155`、`architecture_v1_1_docs/architecture-decisions-v1.1.md:33`、`champions-api-integration-design-v1.0/docs/ingestion-and-provenance-v1.0.md:44-48` は9:30日次、`champions-db-final-design-v1.2/docs/security-transactions-and-update-v1.2.md:32-53` は毎時・当日成功後停止。 | Codexが旧Cron・旧unique制約を復活させる | **更新ポリシーv1.2を唯一の正本**にし、API・ADR・アーキテクチャ・テストを改訂。Cron `0 * * * *`、30分後公開、成功日判定、同日後続外部呼出なし。 | 修正案確定／原稿未改訂 |
| P0-02 | **保存DTOと画面状態の型が一致しない**。フロント`contracts/frontend-state.reference.ts:14,155-156`は`schemaVersion:string`、API `contracts/api-contract.reference.ts:78-79`は`payloadSchemaVersion:1`。フロントの`BattleContextDraft`はtyped condition、API `BattleContextInput`は`flags:string[]`/`extra`。`PokemonBuildDraft`の`status`,`isMega`等もAPIの`ValidatedBuild`と不一致。 | 画面/保存/復元/共有で条件が消える・不正なデータになる | `packages/contracts`等に**唯一のランタイム検証スキーマ＋生成TypeScript DTO**を定義。session draft→validated saved→engine inputの変換と欠落検出を必須化。 | 未解消 |
| P0-03 | **性格倍率UIと合法な性格補正の関係が未決定**。`screen-design-v0.5.md:35-59`は参照能力倍率のみ、`frontend-state-design-v1.0.md:192-198`は5能力ベクトルを保持し選択順位未確定。複数技の物理/特殊が混在すると、単一性格で成立しない補正の組合せがあり得る。 | 間違った能力値・未許可の型を保存する | **単一の合法な性格ベクトル**を正本とし、倍率UI変更時の候補選択/他能力への影響表示をユーザー決定。検証済みの性格マスターに紐付ける。 | ユーザー判断＋マスター検証待ち |
| P0-04 | **マスターデータの出典・作成手順・利用条件・版管理が未確定**。`api-and-dataflow-design-v1.0.md:150-162` と `database-consolidated-v1.2.md:44-56` に構造はあるが、Championsの全フォーム・習得技・技効果・特性・持ち物の採用データセットが未確立。 | 習得技候補/フォーム/特殊効果を正しく提供できない | 出典ごとの利用条件を確認して、ID/フォルム写像、版付きアセット生成、差分監査、全件分類の仕様を作成。 | 技術検証待ち |
| P0-05 | **ゲーム内TOP50との一致が未検証**。`api-validation-results-v1.1.md` でJSON構造は確認済みだがゲーム本体対照なし。DB `decisions-and-gates-v1.2.md:21`も未承認。 | 外部サイト順位を「公式ゲーム内のTOP50」と誤表示 | 形式/レギュレーション/順位の検証証跡を用意。未照合の場合は**出典名と未検証表示**で公開するか、公開保留するかを決定。 | 出典照合＋ユーザー判断待ち |
| P0-06 | **特殊効果・補正順序と16乱数のChampions固有の実証が未完了**。`damage-engine-detailed-design-v1.2.md:9-22,94-118,222-235`は仕様候補と明記。 | 一部計算値を「正確」と断定できない | 効果ごとに`verified_in_game/secondary_source_only/spec_pending`、実装状態、テストフィクスチャを紐付ける。未対応は`unsupported`。対象マスターの全件棚卸しが必須。 | 検証ゲート未達 |
| P0-07 | **共有URLの寿命と古い統計/マスターの保持に未解決の依存**。`auth-save-share-design-v1.0.md:138-143` と DB `decisions-and-gates-v1.2.md:22-26`。永久ミラー禁止方針と永続共有の再現保証が衝突し得る。 | 過去のURLが再現不能／利用条件抵触 | 外部データ保持許可を確認し、共有リンク期限・再現可能期間・`SNAPSHOT_EXPIRED`時のUIを同時に確定。 | ユーザー判断＋規約確認待ち |
| P0-08 | **Codex向けの要求・要件定義の正本ファイルが一式に含まれていない**。v0.2/v0.3の要求・要件は会話中の文章が主で、現存する設計ZIPは分野別。 | 最も優先すべき製品要求が後工程で失われる | ユーザー承認済み事項を`docs/requirements.md`として現行最新版に整理し、`docs/INDEX.md`で旧版をsuperseded指定。 | 受け渡し準備待ち |

### 強く推奨：詳細仕様・品質ゲートの確定（P1）

| ID | 論点 | 対応方法 |
|---|---|---|
| P1-01 | 認証方式（Google/メール等）、共有発行は要ログインか、URL失効操作の扱いが仮案 | ユーザー意思を確認し、Auth UI/API/テストに反映 |
| P1-02 | APIのOpenAPI YAMLの保存`input`,`item`,`stages`等が`additionalProperties:true`で、厳格な入力検証が未表現。`CreateShareRequest`の「snapshotかsavedCalculationIdのどちらか一方」も説明のみ | OpenAPI `oneOf`/discriminator/条件キー制約、Zodを同一正本から生成する |
| P1-03 | `pokemonFormId`と`isMega`の二重表現が曖昧。フォームIDがメガ形態を示す場合の`isMega`の意味が未統一 | フォルム状態と変身条件を分離し、判定と状態の状態遷移・メガストーン制約を決める |
| P1-04 | 細かい条件が必要な技（速度、重量、HP）とUIの非表示能力値との接続が不足 | 必要なときだけ条件欄を展開。未入力は`missingContext`、初期値捏造をしない |
| P1-05 | `56.25%`の表示丸めはUI例`56.2%`と技術文書`56.3%`で未統一 | 計算確率は精密保持。表示1桁の丸め（四捨五入等）を一つに確定、端数境界テスト |
| P1-06 | 長いターンのKO確率モデルは「各ヒットの独立乱数、HP変化なし」に限定されるが、UIのラベルにその前提が未表示 | `詳細`に「命中した場合・回復などを考慮しない」前提説明を追記 |
| P1-07 | 3秒/200組性能目標のテスト端末と初期読み込み条件が未定義 | 推奨端末・モバイル条件・統計キャッシュ条件を決めて計測計画へ |
| P1-08 | 外部データの更新時刻/生成時刻/検知時刻/取込時刻の名称がファイルによって異なる | `sourceGeneratedAt`, `upstreamPublishedAt|null`, `lastCheckedAt`, `importedAt`, `publicationPublishedAt`を標準化 |
| P1-09 | `OpenAPI cookieAuth`の`sb-session`は仮の名前で実際のSupabase SDKと一致する保証なし | SDK管理の認証Cookieを正として、OpenAPIは概念的Auth schemeで説明 |
| P1-10 | 新ランキング検知後、ユーザーが明示切替する際の型override・一時編集中条件をどう通知し破棄するか | フロント設計に確認ダイアログと状態遷移のテストを追加 |

### 任意の改善（P2）

- 命名（リポジトリ名、アプリ画面名`ChampionCalc`等）の統一。
- チャート/HPバーのゲーム色の視覚検証と高コントラスト・色覚差アクセシビリティテスト。
- 保存一覧の検索・件数上限・古い計算の移行案内など、運用UXの詳細。

## 4. 分野間トレーサビリティ（代表例）

| ユーザー要求 | UI | FE State | API/DB | エンジン/検証 | 判定 |
|---|---|---|---|---|---|
| 通常1対1、4技 | v0.5 通常画面 | NormalSession | normal SavedInput | 共通DamageRequest | 整合 |
| TOP50 4技×50匹 | v0.5 一覧 | Top50Session + override | 2形式 publication/snapshot | top50-adapter | 整合・出典保留 |
| 詳細の一時条件 | v0.5 詳細 | detail local reducer | **保存対象から除外** | 詳細だけ再計算 | 整合 |
| ポケモンの型編集をTOP50へ保持 | v0.5 詳細 | defenderOverrides keyed entryId | saved_calculations | 再計算対象1匹 | 整合 |
| 詳細から通常計算へ継承 | v0.5 遷移 | transfer to normal | normal保存可 | 同条件再計算 | 整合 |
| 習得技メニュー + 未習得技の手入力 | コンボボックス | known moveIdのみ確定 | 版付きlearnset/master | 習得可否と計算可否分離 | マスター出典保留 |
| 特性は所持特性のみ | UI v0.5 | abilityId with Pokémon | pokemon_abilities | 合法性検証 | 整合・マスター依存 |
| 実数値入力→ポイント逆算、不可なら`?` | UI v0.5 | invalidDraft | 未確定入力は保存不可 | `invalid` | 整合・特殊フォーム検証待ち |
| 更新完了したら当日停止 | 更新UI | snapshot固定 | DB v1.2 hourly | 対象外 | **古いAPI・ADR文書と矛盾** |
| 保存・共有・端末同期 | 保存一覧/導線 | validated input | revision, token, RLS | 入力から再計算 | APIスキーマ/期限未確定 |

## 5. アーキテクチャのレビュー判断

- **維持**: Next.js + TypeScript、ブラウザ内計算、Supabase PostgreSQL/Auth/Cron、Vercel、Zustand(local detail reducer)、shadcn/ui / Tailwind、Vitest / Playwright。
- **維持**: 2形式を同一publicationで公開するDBモデル。ただしスナップショット「同じpublication」と「上流JSONが同じ更新世代であること」を区別する。
- **修正**: Cronの旧表記、BFF DTO/Frontend DTOの二重定義、特殊効果の未証明事象を試作コード由来の正解値としないこと。
- **要検証**: APIデータ権利、ゲーム本体のランキングとの対照、フォーム/技マスター合法性、エンジンの実機ゴールデンケース。

## 6. 全体レビューの合否

- 製品の構想・UI導線: **合格（UI v0.5を基準として維持）**。
- アーキテクチャ分割と状態所有: **条件付き合格**。
- データ契約: **不合格（契約一本化前）**。
- API/DB更新方式: **条件付き合格（旧契約修正が必要）**。
- ルール/マスターの信頼性: **実証待ち**。
- Codex最終受け渡し: **未承認（P0の解消と正本ファイルの生成が必要）**。

**注記**：本レポートは設計レビュー。ゲームの正確な挙動を検証済みとする文書ではない。P0-06等は実装着手前に仮説/根拠区別を確立し、公開前に実機検証を完了させること。
